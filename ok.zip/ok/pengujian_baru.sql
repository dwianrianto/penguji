-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 08. September 2016 jam 16:26
-- Versi Server: 5.1.41
-- Versi PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pengujian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pengajuan`
--

CREATE TABLE IF NOT EXISTS `detail_pengajuan` (
  `id_detailpengajuan` int(11) NOT NULL AUTO_INCREMENT,
  `no_chasis` varchar(100) NOT NULL,
  `no_engine` varchar(100) NOT NULL,
  `ket_detailpengajuan` varchar(100) NOT NULL,
  `status_input` int(11) NOT NULL,
  `fisik` varchar(100) NOT NULL,
  `panjang` varchar(100) NOT NULL,
  `lebar` varchar(100) NOT NULL,
  `tinggi` varchar(100) NOT NULL,
  `foh` varchar(100) NOT NULL,
  `a` varchar(100) NOT NULL,
  `roh` varchar(100) NOT NULL,
  `i` varchar(100) NOT NULL,
  `ket` varchar(100) NOT NULL,
  `foto` longtext NOT NULL,
  `status_detailpengajuan` int(11) NOT NULL,
  `hasil_cek` varchar(100) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  `id_sk` int(11) NOT NULL,
  PRIMARY KEY (`id_detailpengajuan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `detail_pengajuan`
--

INSERT INTO `detail_pengajuan` (`id_detailpengajuan`, `no_chasis`, `no_engine`, `ket_detailpengajuan`, `status_input`, `fisik`, `panjang`, `lebar`, `tinggi`, `foh`, `a`, `roh`, `i`, `ket`, `foto`, `status_detailpengajuan`, `hasil_cek`, `id_pengajuan`, `id_sk`) VALUES
(1, '9879', 'uiyu', '97987', 0, 'sesuai', '876', '96', '9867', '967', '', '9867', '', 'box besi', '', 0, 'lulus', 1, 1),
(2, '09790', '987897', 'BOX BESI', 0, '', '', '', '', '', '', '', '', '', '', 0, '', 2, 1),
(3, '989890iou98', '889990018299', 'BOX BESI', 0, '', '', '', '', '', '', '', '', '', '', 0, '', 3, 1),
(4, '89898-009', '89890009', 'BOX BESI', 0, 'sesuai', '300', '500', '250', '200', '', '100', '', 'Box Besi', 'sml_Desert.jpg', 0, 'lulus', 4, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_spt`
--

CREATE TABLE IF NOT EXISTS `detail_spt` (
  `id_detailspt` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  PRIMARY KEY (`id_detailspt`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data untuk tabel `detail_spt`
--

INSERT INTO `detail_spt` (`id_detailspt`, `id_pegawai`, `id_pengajuan`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 1, 2),
(5, 2, 2),
(6, 3, 2),
(7, 1, 4),
(8, 2, 4),
(9, 3, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE IF NOT EXISTS `jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `bagian_pegawai` varchar(100) NOT NULL,
  `jabatan_pegawai` varchar(100) NOT NULL,
  `status_jabatan` int(11) NOT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `bagian_pegawai`, `jabatan_pegawai`, `status_jabatan`) VALUES
(1, 'penguji', 'ketua penguji', 0),
(2, 'peguji', 'Anggota Tim', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis`
--

CREATE TABLE IF NOT EXISTS `jenis` (
  `id_jenis` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jenis` varchar(30) NOT NULL,
  `nama_konstruksi` varchar(100) NOT NULL,
  `id_type` int(11) NOT NULL,
  `status_jenis` int(11) NOT NULL,
  PRIMARY KEY (`id_jenis`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `jenis`
--

INSERT INTO `jenis` (`id_jenis`, `nama_jenis`, `nama_konstruksi`, `id_type`, `status_jenis`) VALUES
(1, 'MOBIL BARANG (BAK TERBUKA)', 'ANGKUTAN BARANG', 1, 0),
(2, 'MOBIL BARANG (TANGKI AIR)', 'ANGKUTAN BARANG', 2, 0),
(3, 'Box', 'Angkutan Barang', 3, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` varchar(15) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id_user`, `username`, `password`, `level`) VALUES
(1, 'admin', 'qwerty', 'admin'),
(2, 'kasie', 'qwerty', 'kasie'),
(5, 'kabid', 'qwerty', 'kabid'),
(6, 'rahardian', 'qwerty', 'penguji');

-- --------------------------------------------------------

--
-- Struktur dari tabel `merk`
--

CREATE TABLE IF NOT EXISTS `merk` (
  `id_merk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_merk` varchar(100) NOT NULL,
  `status_merk` int(11) NOT NULL,
  PRIMARY KEY (`id_merk`),
  UNIQUE KEY `nama_merk` (`nama_merk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `merk`
--

INSERT INTO `merk` (`id_merk`, `nama_merk`, `status_merk`) VALUES
(1, 'TOYOTA', 0),
(2, 'MITS', 0),
(3, 'SUZUKI', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `monitoring`
--

CREATE TABLE IF NOT EXISTS `monitoring` (
  `id_monitoring` int(11) NOT NULL AUTO_INCREMENT,
  `id_perusahaan` int(11) NOT NULL,
  `nomor_p` varchar(100) NOT NULL,
  `tgl_p` varchar(100) NOT NULL,
  `jumlah_k` int(11) NOT NULL,
  `no_spt` varchar(100) NOT NULL,
  `tgl_spt` varchar(100) NOT NULL,
  `tgl_cek` varchar(100) NOT NULL,
  `petugas` longtext NOT NULL,
  `jumlah_lulus` int(11) NOT NULL,
  `jumlah_tlulus` int(11) NOT NULL,
  `tgl_bapnaik` varchar(100) NOT NULL,
  `tgl_terbitbap` varchar(100) NOT NULL,
  `jumlah_bap` int(11) NOT NULL,
  `no_seri` varchar(100) NOT NULL,
  `keterangan` longtext NOT NULL,
  `status_monitoring` int(11) NOT NULL,
  PRIMARY KEY (`id_monitoring`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data untuk tabel `monitoring`
--

INSERT INTO `monitoring` (`id_monitoring`, `id_perusahaan`, `nomor_p`, `tgl_p`, `jumlah_k`, `no_spt`, `tgl_spt`, `tgl_cek`, `petugas`, `jumlah_lulus`, `jumlah_tlulus`, `tgl_bapnaik`, `tgl_terbitbap`, `jumlah_bap`, `no_seri`, `keterangan`, `status_monitoring`) VALUES
(19, 6, '0051/AR/SM/VI/2016', '14-06-2016', 17, '456/-1.811.111', '16-06-2016', '16-06-2016', 'Penguji', 17, 0, '20-06-2016', '22-06-2016', 15, '', 'sudah selesai', 1),
(18, 11, '0026/PPFKB/V-CLASS/VI-16', '14-06-2016', 19, '457/-1.811.111', '16-06-2016', '16-06-2016', 'Penguji', 19, 0, '17-06-2016', '20-06-2016', 19, '', 'sudah selesai', 1),
(17, 6, '047/AR/SM/V/2016', '31-05-2016', 13, '458/-1.811.111', '16-06-2016', '20-06-2016', 'Penguji', 13, 0, '22-06-2016', '22-06-2016', 13, '', 'sudah selesai', 1),
(16, 2, '04/CV/BJ/06/2016', '14-06-2016', 7, '459/-1.811.111', '16-06-2016', '20-06-2016', 'Penguji', 7, 0, '15-06-2016', '29-06-2016', 7, '', 'sudah selesai', 1),
(15, 17, '155/PSD-LOC-091/2016', '14-06-2016', 11, '451/-1.811.111', '16-06-2016', '17-06-2016', 'Penguji', 11, 0, '15-06-2016', '17-06-2016', 11, '', 'sudah selesai', 1),
(14, 5, '025/ADM/AKP/VI/16', '14-06-2016', 17, '460/-1.811.111', '16-06-2016', '20-06-2016', 'Penguji', 17, 0, '20-06-2016', '22-06-2016', 17, '', 'sudah selesai', 1),
(13, 4, 'LUTE/MAD/655/VI/2016', '14-06-2016', 2, '461/-1811.111', '16-06-2016', '16-06-2016', 'Penguji', 2, 0, '17-06-2016', '17-06-2016', 2, '', 'sudah selesai', 1),
(20, 15, '012/MS/RI/VI-2016', '14-06-2016', 9, '455/-1.811.111', '16-06-2016', '16-06-2016', 'Penguji', 9, 0, '17-06-2016', '17-06-2016', 9, '0031401-0031409', 'sudah selesai', 1),
(21, 9, '092/STS/06/2016', '14-06-2016', 13, '454/-1.811.111', '16-06-2016', '17-06-2016', 'Penguji', 13, 0, '15-06-2016', '16-06-2016', 13, '', 'sudah selesai', 1),
(22, 14, '092/SQI-ADM/VI/2016', '14-06-2016', 4, '452/-1.811.111', '16-06-2016', '16-06-2016', 'Penguji', 4, 0, '12-06-2016', '12-06-2016', 4, '', 'sudah selesai', 1),
(23, 10, '004/STM/UM/VI/16', '14-06-2016', 15, '453/1.811.111', '16-06-2016', '17-06-2016', 'Penguji', 15, 0, '16-06-2016', '21-06-2016', 0, '', 'sudah selesai', 1),
(24, 12, '085/PFKB/KTS/VI./2016', '14-06-2016', 6, '450/-1.811/111', '16-06-2016', '17-06-2016', 'Penguji', 6, 0, '20-06-2016', '21-06-2016', 0, 'B.0031476-B0031481', 'sudah selesai', 1),
(25, 10, '003/STM/UM/VI/16', '10-06-2016', 14, '443/-1.811.111', '14-06-2016', '14-06-2016', 'PENGUJI', 15, 0, '15-06-2016', '16-06-2016', 15, '0031320-0031333;0031335', '', 1),
(26, 13, '35/VI/SLY/16', '10-06-2016', 15, '441/-1.811.111', '14-06-2016', '14-06-2016', 'PENGUJI', 15, 0, '15-06-2016', '16-06-2016', 15, '0031288-0031302;0031304', 'sudah selesai', 1),
(27, 12, '084/PFKB/KTS/VI/16', '10-06-2016', 11, '440/-1.811.111', '14-06-2016', '14-06-2016', 'PENGUJI', 11, 0, '15-06-2016', '16-06-2016', 11, '0031263-0031273', 'sudah selesai', 1),
(28, 18, '24/SMP/VI/2016', '10-06-2016', 17, '439/-1.811.111', '14-06-2016', '14-06-2016', 'PENGUJI', 17, 0, '15-06-2016', '16-06-2016', 17, '0031303-0031313', 'sudah selesai', 1),
(29, 9, '041/STS/06/2016', '10-06-2016', 14, '442/-1.811.111', '14-06-2016', '14-06-2016', 'PENGUJI', 14, 2, '15-06-2016', '16-06-2016', 14, '0031274-0031287', 'sudah selesai', 1),
(30, 19, '014/PAS-UM/VI/16', '10-06-2016', 4, '446/-1.811.111', '14-06-2016', '15-06-2016', 'PENGUJI', 3, 0, '16-06-2016', '17-06-2016', 4, '0031245-0031248', 'sudah selesai', 1),
(31, 5, '024/ADM/AKP/VI/16', '07-06-2016', 20, '449/-1.811.111', '14-06-2016', '15-06-2016', 'H.Kasman.cs', 20, 0, '16-06-2016', '17-06-2016', 20, '0031210-0031215;0031231-0031240; 0031206', 'sudah selesai', 1),
(32, 6, '0050/AR/SM/VI/2016', '10-06-2016', 27, '447/-1.811.111', '14-06-2016', '16-06-2016', 'PENGUJI', 24, 0, '16-06-2016', '17-06-2016', 27, '0031351-0031377', 'sudah selesai', 1),
(33, 2, '03/CV/BJ/06/16', '10-06-2016', 10, '448/-1.811.111', '14-06-2016', '15-06-2016', 'PENGUJI', 10, 0, '16-06-2016', '17-06-2016', 10, '0031187-0031195;0031244', 'sudah selesai', 1),
(34, 8, '002/JFT/VI/2016', '10-06-2016', 8, '445/-1.811.111', '14-06-2016', '15-06-2016', 'PENGUJI', 8, 0, '16-06-2016', '17-06-2016', 8, '0031201-0031205;0031198-0031200', 'sudah selesai', 1),
(35, 1, '026/spf akma/1v', '17-06-2016', 36, '', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 36, 0, '21-06-2016', '24-06-2016', 36, '', 'sudah selesai', 1),
(36, 5, '024/ADM/AKP/VI/16', '17-06-2016', 6, '466/-1.811.111', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 6, 0, '21-06-2016', '24-06-2016', 6, 'B0031727-31732', 'sudah selesai', 1),
(37, 19, '015/pas/um/v1/16', '17-06-2016', 7, '462/-1.811.111', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 7, 0, '21-06-2016', '24-06-2016', 7, 'B0031733-0031739', 'sudah selesai', 1),
(38, 12, '086/pfkb/kts/v1/16', '17-06-2016', 7, '450/-1.811/111', '16-06-2016', '16-06-2016', 'H.Kasman.cs', 7, 0, '17-06-2016', '21-06-2016', 7, '0031476-0031481', 'sudah selesai', 1),
(39, 13, '36/v1/sly/16', '17-06-2016', 9, '464/i.8.11.111', '20-06-2016', '17-06-2016', 'H.Kasman.cs', 9, 0, '19-06-2016', '24-06-2016', 9, 'B.0031587-0031595', 'sudah selesai', 1),
(40, 6, '0052/AR/SM/V1/16', '17-06-2016', 16, '472/-1.8.11.111', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 0, 16, '20-06-2016', '24-06-2016', 17, 'B.0031701-31716', 'sudah selesai', 1),
(41, 20, '12/3K/BPA/V/16', '17-06-2016', 3, '467/-1.8.11.111', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 3, 0, '21-06-2016', '24-06-2016', 3, 'B0031740-31742', 'sudah selesai', 1),
(42, 2, '5/CV/BJ/06/16', '17-06-2016', 8, '470/1.811.111', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 8, 0, '21-06-2016', '24-06-2016', 8, '', 'sudah selesai', 1),
(43, 11, '0027/PPFKB/V class/v1/16', '17-06-2016', 10, '469/-1.811.111', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 10, 0, '21-06-2016', '24-06-2016', 10, 'B.0031378-31387', 'sudah selesai', 1),
(44, 17, '155/psd-lot -091/2016', '13-06-2016', 11, '451/-1.811.111', '16-06-2016', '16-06-2016', 'H.Kasman.cs', 11, 0, '17-06-2016', '21-06-2016', 11, 'B.0031337-B0031346', 'sudah selesai', 1),
(45, 10, '004/STM/UM/V1/16', '17-06-2016', 15, '453/1.811.111', '20-06-2016', '20-06-2016', 'H.Kasman.cs', 15, 0, '17-06-2016', '20-06-2016', 15, 'B0031348-B0031462', 'sudah selesai', 1),
(46, 9, '043/STS/06/16', '17-06-2016', 13, '454/-1.811.111', '20-06-2016', '20-06-2016', '', 13, 0, '17-06-2016', '', 13, 'B,0031463-B0031475', 'sudah selesai', 1),
(47, 4, 'LUTE/MAD/655/VI/2016', '14-06-2016', 17, '', '', '', '', 17, 0, '', '', 0, '', '', 1),
(48, 15, '012/MS/RI/VI-2016', '14-06-2016', 9, '455/-1.811.111', '16-06-2016', '16-06-2016', 'H.Kasman.cs', 9, 0, '17-06-2016', '17-06-2016', 9, '', 'SUDAH SELESAI', 1),
(49, 14, '092/SQI-ADM/VI/2016', '14-06-2016', 4, '452/-1.811.111', '16-06-2016', '16-06-2016', 'H.Kasman.cs', 4, 0, '17-06-2016', '17-06-2016', 4, '', 'sudah selesai', 1),
(50, 4, 'LUTE/MAD/655/VI/2016', '14-06-2016', 2, '461/-1811.111', '16-06-2016', '16-06-2016', 'H.Kasman.cs', 2, 0, '17-06-2016', '17-06-2016', 17, '', 'sudah selesai', 1),
(51, 18, '24/SMP/VI/2016', '10-06-2016', 17, '439/-1.811.111', '14-06-2016', '14-06-2016', 'H.Kasman.cs', 17, 1, '15-06-2016', '23-06-2016', 14, '', 'sudah selesai', 1),
(52, 9, '041/STS/06/2016', '10-06-2016', 14, '442/-1.811.111', '14-06-2016', '14-06-2016', 'H.Kasman.cs', 14, 0, '15-06-2016', '23-06-2016', 14, '', 'sudah selesai', 1),
(53, 13, '34/VI/SLY/2016', '07-06-2016', 15, '431/-18.11.111', '09-06-2016', '09-06-2016', 'H.Kasman.cs', 15, 0, '10-06-2016', '23-06-2016', 15, '', 'sudah selesai', 1),
(54, 10, '003/STM/UM/VI/16', '10-06-2016', 15, '443/-1.811.111', '14-06-2016', '14-06-2016', 'H.Kasman.cs', 15, 0, '14-06-2016', '23-06-2016', 15, '', 'sudah selesai', 1),
(55, 13, '35/VI/SLY/16', '10-06-2016', 15, '441/-1.811.111', '14-06-2016', '14-06-2016', 'H.Kasman.cs', 9, 0, '17-06-2016', '23-06-2016', 14, '', 'sudah selesai', 1),
(56, 12, '084/PFKB/KTS/VI/16', '10-06-2016', 11, '440/-1.811.111', '14-06-2016', '14-06-2016', 'H.Kasman.cs', 11, 0, '16-06-2016', '23-06-2016', 11, '', 'sudah selesai', 1),
(57, 5, '027/ADM-AKP/VI/16', '21-06-2016', 14, '477/-18.11.111', '22-06-2016', '23-06-2016', 'Kasman; M.Yulhadianur; Hendra', 14, 0, '24-06-2016', '27-06-2016', 14, 'B.0031782 s/d B.0031795', 'sudah selesai', 1),
(58, 7, '08 / WGS / K-1 / V / 16', '21-06-2016', 12, '482/-18.11.111', '22-06-2016', '23-06-2016', 'Utang Sopyandi; Arie Fitriadi; Rahadian', 12, 0, '27-06-2016', '27-06-2016', 12, 'B.0031106 s/d B.0031119', 'sudah selesai', 1),
(59, 11, '0028/PPPFKB/V.CLAS/V/16', '21-06-2016', 15, '481', '22-06-2016', '23-06-2016', 'Utang Sopyandi; Arie Fitriadi; Rahadian', 15, 0, '24-06-2016', '27-06-2016', 15, 'B.0031717 s/d B.0031726 dan B.0031388 s/d B.0031392', '', 1),
(60, 6, '0053/AR/SMVI/16', '21-06-2016', 17, '475', '22-06-2016', '23-06-2016', 'Kasman; M.Yulhadianur; Hendra', 17, 0, '24-06-2016', '27-06-2016', 17, 'B.0031751 s.d B.0031767', '', 1),
(61, 12, '087/PFKB/KTS/VI/16', '21-06-2016', 12, '484', '22-06-2016', '24-06-2016', 'H.Kasman.cs', 12, 0, '27-06-2016', '', 12, 'B.0041049 s/d                                                                                       ', 'sudah selesai', 1),
(62, 10, '007/STM/UM/VI/16', '21-06-2016', 15, '478', '22-06-2016', '24-06-2016', 'H.Kasman.cs', 15, 0, '27-06-2016', '28-06-2016', 15, 'B.0031611 s/d B.0031625 ; B.0031483 ; Rusak B.0031611', 'sudah selesai', 1),
(63, 18, '26/SMP/VI/2016', '21-06-2016', 10, '474/-18.11.111', '22-06-2016', '24-06-2016', 'H.Kasman.cs', 10, 0, '27-06-2016', '', 10, 'B.0031667 s/d B.0031676', 'sudah selesai', 1),
(64, 9, '044/STS/06/2016', '21-06-2016', 14, '479/-1.8.11.111', '22-06-2016', '24-06-2016', 'Penguji', 14, 0, '27-06-2016', '', 14, 'B.0031601 s/d B.0031610 ; B.0031677 s/d B.0031680', '', 1),
(65, 5, '028/ADM/AKP/VI/16', '28-06-2016', 5, '492/-1.811.111', '24-06-2016', '27-06-2016', 'H.Kasman.cs', 5, 5, '27-06-2016', '29-06-2016', 5, '0031802', 'sudah selesai', 1),
(67, 6, '0054/AR/SM/VI-16', '24-06-2016', 17, '486/-1.811.111', '28-06-2016', '28-06-2016', 'H.Kasman.cs', 17, 0, '28-06-2016', '29-06-2016', 17, '0031743', 'sudah selesai', 1),
(68, 21, 'out/msp/VI/16/0172', '21-06-2016', 1, '476/.1811.111', '27-06-2016', '27-06-2016', 'H.Kasman.cs', 0, 1, '28-06-2016', '29-06-2016', 1, '', 'kendaraan belum selesai', 1),
(69, 1, '029/spf-AKMA/VI/16', '24-06-2016', 10, '490/-1.811.111', '28-06-2016', '29-06-2016', 'H.Kasman.cs', 10, 0, '28-06-2016', '30-06-2016', 10, 'B0031691-0031700', 'sudah selesai', 1),
(70, 1, '029/spf-AKMA/VI/16', '24-06-2016', 10, '490/-1.811.111', '28-06-2016', '28-06-2016', 'H.Kasman.cs', 10, 0, '29-06-2016', '30-06-2016', 7, 'B0031691-0031700', 'sudah selesai', 1),
(71, 9, '045/STS/06/16', '24-06-2016', 15, '491/-1811.111', '27-06-2016', '28-06-2016', 'H.Kasman.cs', 10, 0, '29-06-2016', '30-06-2016', 10, 'B0031691-0031700', 'sudah selesai', 1),
(72, 10, '488/STM/UM/VI/2016', '24-06-2016', 15, '488.28/6/16', '27-06-2016', '27-06-2016', 'H.Kasman.cs', 15, 0, '28-06-2016', '30-06-2016', 15, 'BB0031484-B.0031897', 'sudah selesai', 1),
(73, 12, '088/PFKB/KTS/VI/16', '24-06-2016', 17, '487.-1.811.111', '28-06-2016', '28-06-2016', 'H.Kasman.cs', 17, 0, '29-06-2016', '30-06-2016', 17, 'B.0031881-B.0031897', 'sudah selesai', 1),
(74, 13, '37/VI/SLY/2016', '24-06-2016', 15, '489.1.811.111', '28-06-2016', '28-06-2016', 'H.Kasman.cs', 15, 0, '28-06-2016', '28-06-2016', 15, 'B.0031851-B.0031865', 'sudah selesai', 1),
(75, 13, '37/VI/SLY/2016', '24-06-2016', 15, '489.1.811.111', '28-06-2016', '28-06-2016', 'H.Kasman.cs', 15, 0, '28-06-2016', '28-06-2016', 15, 'B.0031851-B.0031865', 'sudah selesai', 1),
(76, 19, '016/PAS-UM/VI/16', '24-06-2016', 3, '485/-1.811.111', '28-06-2016', '28-06-2016', 'H.Kasman.cs', 3, 0, '27-06-2016', '30-06-2016', 3, '', 'sudah selesai', 1),
(77, 4, 'LUTE/MAD/658/VI/2016', '21-06-2016', 23, '480/-1.811.111', '27-06-2016', '27-06-2016', 'H.Kasman.cs', 23, 0, '24-06-2016', '30-06-2016', 23, '', 'sudah selesai', 1),
(78, 23, '015/TSM/VI/2016', '21-07-2016', 2, '483/1.811.111', '27-07-2016', '27-07-2016', 'H.Kasman.cs', 2, 0, '28-07-2016', '30-07-2016', 2, '', 'sudah selesai', 1),
(80, 4, 'LUTE / MAD / 670 / 670 / VI / 16', '28-06-2016', 5, '498', '19-07-2016', '19-07-2016', 'Penguji', 5, 0, '20-07-2016', '', 5, 'B.0031907 - B.0031911', '', 0),
(81, 1, '031 / SPF / AKMA / VII / 16', '12-07-2016', 11, '495', '19-07-2016', '19-07-2016', 'Penguji', 11, 0, '20-07-2016', '', 11, 'B.0031901 - B.0031906 ; B0031996 - B.0032000 .', '', 0),
(82, 11, '0030 / PPPFKB / V-CLAS / VII-16', '15-07-2016', 18, '497', '19-07-2016', '19-07-2016', 'Penguji', 18, 0, '20-07-2016', '', 18, 'B.0031978 - B.0031995', '', 0),
(83, 6, '0055 / AR / SM / VII / 16', '15-07-2016', 24, '496', '19-07-2016', '19-07-2016', 'Penguji', 24, 0, '20-07-2016', '', 24, 'B.0031954 - B.0031977', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `no_transaksi`
--

CREATE TABLE IF NOT EXISTS `no_transaksi` (
  `id_nomortransaksi` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_nomortransaksi` varchar(30) NOT NULL,
  `tupoksi_kts` varchar(30) NOT NULL,
  `jumlah_nomortransaksi` int(11) NOT NULL,
  PRIMARY KEY (`id_nomortransaksi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `no_transaksi`
--

INSERT INTO `no_transaksi` (`id_nomortransaksi`, `jenis_nomortransaksi`, `tupoksi_kts`, `jumlah_nomortransaksi`) VALUES
(1, 'pengajuan', '-1.811.111', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `id_pegawai` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(100) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `bagian_pegawai` varchar(100) NOT NULL,
  `jabatan_pegawai` varchar(100) NOT NULL,
  `status_pegawai` int(11) NOT NULL,
  PRIMARY KEY (`id_pegawai`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nip`, `nama_pegawai`, `bagian_pegawai`, `jabatan_pegawai`, `status_pegawai`) VALUES
(1, '19600507 198503 1 011', 'Utang Sopyandi', 'Penguji', 'Ketua Tim', 0),
(2, '19820713 201001 1 024', 'Arie Fitriadi, ST', 'Penguji', 'Anggota Tim', 0),
(3, '19760630 200701 1 017', 'Rahardian', 'Penguji', 'Anggota Tim', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengajuan`
--

CREATE TABLE IF NOT EXISTS `pengajuan` (
  `id_pengajuan` int(11) NOT NULL AUTO_INCREMENT,
  `no_pengajuan` longtext NOT NULL,
  `id_perusahaan` int(11) NOT NULL,
  `perihal_pengajuan` longtext NOT NULL,
  `tgl_pengajuan` varchar(20) NOT NULL,
  `status_pengajuan` int(11) NOT NULL,
  `disposisi` int(11) NOT NULL,
  `status_unit` int(11) NOT NULL,
  `status_spt` int(11) NOT NULL,
  `kasie_a` int(11) NOT NULL,
  `tglkasie_a` varchar(100) NOT NULL,
  `kabid_a` int(11) NOT NULL,
  `tglkabid_a` varchar(100) NOT NULL,
  `status_cek` int(11) NOT NULL,
  `kasie_b` int(11) NOT NULL,
  `tglkasie_b` date NOT NULL,
  `kabid_b` int(11) NOT NULL,
  `tglkabid_b` date NOT NULL,
  PRIMARY KEY (`id_pengajuan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `pengajuan`
--

INSERT INTO `pengajuan` (`id_pengajuan`, `no_pengajuan`, `id_perusahaan`, `perihal_pengajuan`, `tgl_pengajuan`, `status_pengajuan`, `disposisi`, `status_unit`, `status_spt`, `kasie_a`, `tglkasie_a`, `kabid_a`, `tglkabid_a`, `status_cek`, `kasie_b`, `tglkasie_b`, `kabid_b`, `tglkabid_b`) VALUES
(1, '987987', 1, 'Pemeriksaan Kendaraan', '26-07-2016', 0, 1, 1, 1, 1, '26-07-2016', 1, '26-07-2016', 1, 1, '0000-00-00', 1, '0000-00-00'),
(2, '098097', 3, 'Pemeriksaan Kendaraan', '24-08-2016', 0, 1, 1, 1, 1, '03-09-2016', 1, '03-09-2016', 0, 0, '0000-00-00', 0, '0000-00-00'),
(3, '8990/12/2016', 7, 'Pemeriksaan Kendaraan', '08-09-2016', 0, 1, 1, 0, 1, '08-09-2016', 0, '', 0, 0, '0000-00-00', 0, '0000-00-00'),
(4, '8999898/2016', 5, 'Pemeriksaan Kendaraan', '08-09-2016', 0, 1, 1, 1, 1, '08-09-2016', 1, '08-09-2016', 0, 0, '0000-00-00', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perusahaan`
--

CREATE TABLE IF NOT EXISTS `perusahaan` (
  `id_perusahaan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_perusahaan` longtext NOT NULL,
  `jenis_perusahaan` longtext NOT NULL,
  `alamat_perusahaan` longtext NOT NULL,
  `penanggung_jawab` varchar(100) NOT NULL,
  `telp_perusahaan` longtext NOT NULL,
  `telp_perusahaan2` varchar(100) NOT NULL,
  `telp_perusahaan3` varchar(100) NOT NULL,
  `fax_perusahaan` varchar(100) NOT NULL,
  `npwp` varchar(100) NOT NULL,
  `siup` varchar(100) NOT NULL,
  `masa_siup` varchar(100) NOT NULL,
  `status_perusahaan` int(11) NOT NULL,
  PRIMARY KEY (`id_perusahaan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data untuk tabel `perusahaan`
--

INSERT INTO `perusahaan` (`id_perusahaan`, `nama_perusahaan`, `jenis_perusahaan`, `alamat_perusahaan`, `penanggung_jawab`, `telp_perusahaan`, `telp_perusahaan2`, `telp_perusahaan3`, `fax_perusahaan`, `npwp`, `siup`, `masa_siup`, `status_perusahaan`) VALUES
(1, 'CV. ANUGERAH KARYA MANDIRI', 'KAROSERI', 'Jl. Pelopor IV No. 17 RT. 01/05 Tegal Alur Kalideres Jakarta\r\n', 'YACOBU SUGIHARTO', '55959140', '55955452', '', '55963272', '350.123.1.909.1.1', '3434.2343432.234234', '2016-12-15', 0),
(2, 'CV. BAGUS JAYA', 'KAROSERI', 'Jl. Garuda Gg. Mangga No. 1 Kemayoran Jakarta\r\n', 'YUWITA, SE', '4243864', '82431446', '8250373', '8250425', '', '', '', 0),
(3, 'CV. CITRA MANGGALA KARYA', 'KAROSERI', 'Jl. Raya Daan Mogot KM. 10 No. 5 Jakarta Barat\r\n', 'FRANGKY', '5455088', '5455089', '', '5417338', '', '', '', 0),
(4, 'CV. SANTAM TRAILINDO JAKARTA', 'KAROSERI', 'Jl. Raya Cakung No. 36 A Cilincing Jakarta Utara\r\n', 'ILYAS BAKHRI HAFIZD', '44830546', '', '', '44830546', '', '', '', 0),
(5, 'CV. YANATTA USAHA MANDIRI', 'KAROSERI', 'Jl. Raya Lebak Bulus N+o. 53, Jakarta Selatan\r\n', 'RAMONA', '', '', '', '', '', '', '', 0),
(6, 'KARYA TEKNIK SERVICE', 'KAROSERI', 'Jl. Kapuk Muara No. 1 - 2  Jakarta\r\n', 'SUGANDA JENY', '5406325', '5455502', '9156575', '5406325', '', '', '', 0),
(7, 'PT. ABILINDO LINTAS PERSADA', 'KAROSERI', 'Jl. Ganggeng III No. 14 Sungai Bambu, Tanjung Priok - Jakarta\r\n', 'YOHANES. S', '43936079', '', '', '43936086', '', '', '', 0),
(8, 'PT. ADHIKARISMA PRATAMA', 'KAROSERI', 'Jl. Tipar Cakung KM. 23 No. 20  Jakarta\r\n', 'Ir. ANDIYANTO WARDHANA', '46835427', '46835428', '', '46835430', '', '', '', 0),
(9, 'PT. ADICITRA BHIRAWA', 'KAROSERI', 'Jl. Raya Pegangsaan Dua No. 88 Jakarta\r\n', 'F.X. SUSANTO', '44837033', '', '', '44837036', '', '', '', 0),
(10, 'PT. AMAN SINAMBUNG KARYA', 'KAROSERI', 'Jl. Samanhudi No. 20 Lt II Jakarta Pusat\r\n', 'RINI GUNAWAN', '3840703', '655555', '', '654555', '', '', '', 0),
(11, 'PT. ANTIKA RAYA NIAGANUSA', 'KAROSERI', 'Jl. Raya Cakung Cilincing KM.1,23 Jakarta\r\n', 'FERRY TENACIUS', '4611717', '', '', '4613838', '', '', '', 0),
(19, 'PT. BUMINDO GASUTAMA', 'KAROSERI', 'Jl. Agung Utara Raya Blok M No. 58-59 Taman Nyiur, Sunter Podomoro, Jakarta\r\n', 'Agus Suryanto', '65831008', '8646688', '', '6504465', '', '', '', 0),
(18, 'PT. BUANA PAKSI ABADI', 'KAROSERI', 'Jl. Raya Setu RT.004/001 Cipayung Jakarta\r\n', 'DIAN HADI', '84974987', '', '', '84974987', '', '', '', 0),
(17, 'PT. BOC GASES INDONESIA', 'KAROSERI', 'Jl. Raya Bekasi KM 21 Pulogadung Jakarta\r\n', 'AGUS DWI PUTRANTO', '4601793', '4602785', '', '4602789', '', '', '', 0),
(16, 'PT. ANUGRAH CITRA REKONINDO', 'KAROSERI', 'Jl. Raya Bekasi Cakung Km.23 Jakarta\r\n', 'RUSMINO', '46824422', '46824433', '46825015', '', '', '', '', 0),
(20, 'PT. CAKRA INFOTIKA CITRANUSA', 'KAROSERI', 'Jl. Jatibarang V/39 Rawamangun Jakarta Timur\r\n', 'INA MARFIANI, SE, MM', '4892593', '4890636', '', '4892593', '', '', '', 0),
(21, 'PT. CENTRAL AUTO COMPERINDO', 'KAROSERI', 'Jl. Raya Bogor Km.19/39 Kramat Jati Jakarta\r\n', 'Drs. RADMAN HARTONO', '86860130', '86861602', '', '8672126', '', '', '', 0),
(22, 'PT. Sumber Teknik Service', 'Karoseri', 'Jl. Kapuk Utara 14460', 'Joko', '09890790', '0709879', '097097', '09709870', '', '', '', 0),
(23, 'PT. UNITED TRACTORS P.E ', 'KAROSERI', 'Jl. Raya Km. 22 Jakarta', '', '', '', '', '', '', '', '', 0),
(24, 'PT. CIPTA LAKSANA ARMADA SELARAS', 'KAROSERI', 'Jl. Raya Bekasi Km. 24,5 Ujung Menteng Jakarta', 'Drs. Sularjo', '70775205', '88970599', '', '88970599', '', '', '', 0),
(25, 'PT. TRESNA SUKSES MANDIRI', 'KAROSERI', 'Jl. Pulogadung Indah Selatan No. 11 Rt 005 / 011 Pulogebang', 'Sartono', '47803078', '70305643', '', '46824431', '', '', '', 0),
(26, 'SUMBER TEKNIK SERVICE', 'KAROSERI', 'Jl. Kapuk Muara No. 25/26/27 A Jakarta', 'C. Atmono', '6195347', '5405544', '', '619574', '', '', '', 0),
(27, 'PT SUMBER MOTOR PERKASA', 'KAROSERI', 'Jl. Kapuk Raya No.166 - 168 Jakarta', 'Wiryanto', '54373146', '54373147', '54373148', '54373145', '', '', '', 0),
(28, 'SUMBER TEKNIK MOTOR', 'KAROSERI', 'Jl. Kapuk Muara Blok A. No. 21-24 Jakarta Utara', 'Wieliem Leo Chandra', '5405543', '66601580', '66601634', '66601610', '', '', '', 0),
(29, 'PT. INDOSALUYU PRIMAJAYA', 'KAROSERI', 'Jl. Daan Mogot No. 52 Km 12 Jakarta', 'Jackson', '6190513', '6191793', '5404413', '6190451', '', '', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `sk`
--

CREATE TABLE IF NOT EXISTS `sk` (
  `id_sk` int(11) NOT NULL AUTO_INCREMENT,
  `no_sk` varchar(30) NOT NULL,
  `tgl_sk` varchar(20) NOT NULL,
  `foh_sk` varchar(100) NOT NULL,
  `roh_sk` varchar(100) NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `status_sk` int(11) NOT NULL,
  PRIMARY KEY (`id_sk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `sk`
--

INSERT INTO `sk` (`id_sk`, `no_sk`, `tgl_sk`, `foh_sk`, `roh_sk`, `id_jenis`, `status_sk`) VALUES
(1, '3647/AJ.410/DRJD/2012', '27-09-2012', '', '', 1, 0),
(2, '3652/AJ.402/DRJD/2009', '09-11-2009', '', '', 2, 0),
(3, '2324/AJ.402/DRJ/2007', '20-06-2007', '', '', 3, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `spt`
--

CREATE TABLE IF NOT EXISTS `spt` (
  `id_spt` int(11) NOT NULL AUTO_INCREMENT,
  `no_spt` varchar(100) NOT NULL,
  `tgl_spt` varchar(100) NOT NULL,
  `status_spt` int(11) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  PRIMARY KEY (`id_spt`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `spt`
--

INSERT INTO `spt` (`id_spt`, `no_spt`, `tgl_spt`, `status_spt`, `id_pengajuan`) VALUES
(1, '1/-1.811.111', '', 0, 1),
(2, '2/-1.811.111', '', 0, 2),
(3, '3/-1.811.111', '', 0, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `nama_type` varchar(30) NOT NULL,
  `id_merk` int(11) NOT NULL,
  `status_type` int(11) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `type`
--

INSERT INTO `type` (`id_type`, `nama_type`, `id_merk`, `status_type`) VALUES
(1, '110 ST LONG', 1, 0),
(2, '110 ET', 1, 0),
(3, 'L300', 2, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `id_unit` int(11) NOT NULL AUTO_INCREMENT,
  `chasis` varchar(100) NOT NULL,
  `engine` varchar(100) NOT NULL,
  `ket` varchar(100) NOT NULL,
  `status_unit` int(11) NOT NULL,
  `jumlah_ujiunit` int(11) NOT NULL,
  PRIMARY KEY (`id_unit`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `unit`
--

INSERT INTO `unit` (`id_unit`, `chasis`, `engine`, `ket`, `status_unit`, `jumlah_ujiunit`) VALUES
(1, '9879', 'uiyu', '97987', 0, 1),
(2, '09790', '987897', 'BOX BESI', 0, 1),
(3, '989890iou98', '889990018299', 'BOX BESI', 0, 1),
(4, '89898-009', '89890009', 'BOX BESI', 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
