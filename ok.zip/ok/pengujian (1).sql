-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 26. Juli 2016 jam 13:58
-- Versi Server: 5.1.41
-- Versi PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pengujian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pengajuan`
--

CREATE TABLE IF NOT EXISTS `detail_pengajuan` (
  `id_detailpengajuan` int(11) NOT NULL AUTO_INCREMENT,
  `no_chasis` varchar(100) NOT NULL,
  `no_engine` varchar(100) NOT NULL,
  `ket_detailpengajuan` varchar(100) NOT NULL,
  `status_input` int(11) NOT NULL,
  `fisik` varchar(100) NOT NULL,
  `panjang` varchar(100) NOT NULL,
  `lebar` varchar(100) NOT NULL,
  `tinggi` varchar(100) NOT NULL,
  `foh` varchar(100) NOT NULL,
  `a` varchar(100) NOT NULL,
  `roh` varchar(100) NOT NULL,
  `i` varchar(100) NOT NULL,
  `ket` varchar(100) NOT NULL,
  `foto` longtext NOT NULL,
  `status_detailpengajuan` int(11) NOT NULL,
  `hasil_cek` varchar(100) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  `id_sk` int(11) NOT NULL,
  PRIMARY KEY (`id_detailpengajuan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data untuk tabel `detail_pengajuan`
--


-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_spt`
--

CREATE TABLE IF NOT EXISTS `detail_spt` (
  `id_detailspt` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  PRIMARY KEY (`id_detailspt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data untuk tabel `detail_spt`
--


-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE IF NOT EXISTS `jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `bagian_pegawai` varchar(100) NOT NULL,
  `jabatan_pegawai` varchar(100) NOT NULL,
  `status_jabatan` int(11) NOT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `bagian_pegawai`, `jabatan_pegawai`, `status_jabatan`) VALUES
(1, 'penguji', 'ketua penguji', 0),
(2, 'peguji', 'Anggota Tim', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis`
--

CREATE TABLE IF NOT EXISTS `jenis` (
  `id_jenis` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jenis` varchar(30) NOT NULL,
  `nama_konstruksi` varchar(100) NOT NULL,
  `id_type` int(11) NOT NULL,
  `status_jenis` int(11) NOT NULL,
  PRIMARY KEY (`id_jenis`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `jenis`
--

INSERT INTO `jenis` (`id_jenis`, `nama_jenis`, `nama_konstruksi`, `id_type`, `status_jenis`) VALUES
(1, 'MOBIL BARANG (BAK TERBUKA)', 'ANGKUTAN BARANG', 1, 0),
(2, 'MOBIL BARANG (TANGKI AIR)', 'ANGKUTAN BARANG', 2, 0),
(3, 'Box', 'Angkutan Barang', 3, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` varchar(15) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id_user`, `username`, `password`, `level`) VALUES
(1, 'admin', 'qwerty', 'admin'),
(2, 'kasie', 'qwerty', 'kasie'),
(5, 'kabid', 'qwerty', 'kabid'),
(6, 'rahardian', 'qwerty', 'penguji');

-- --------------------------------------------------------

--
-- Struktur dari tabel `merk`
--

CREATE TABLE IF NOT EXISTS `merk` (
  `id_merk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_merk` varchar(100) NOT NULL,
  `status_merk` int(11) NOT NULL,
  PRIMARY KEY (`id_merk`),
  UNIQUE KEY `nama_merk` (`nama_merk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `merk`
--

INSERT INTO `merk` (`id_merk`, `nama_merk`, `status_merk`) VALUES
(1, 'TOYOTA', 0),
(2, 'MITS', 0),
(3, 'SUZUKI', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `monitoring`
--

CREATE TABLE IF NOT EXISTS `monitoring` (
  `id_monitoring` int(11) NOT NULL AUTO_INCREMENT,
  `id_perusahaan` int(11) NOT NULL,
  `nomor_p` varchar(100) NOT NULL,
  `tgl_p` varchar(100) NOT NULL,
  `jumlah_k` int(11) NOT NULL,
  `no_spt` varchar(100) NOT NULL,
  `tgl_spt` varchar(100) NOT NULL,
  `tgl_cek` varchar(100) NOT NULL,
  `petugas` longtext NOT NULL,
  `jumlah_lulus` int(11) NOT NULL,
  `jumlah_tlulus` int(11) NOT NULL,
  `tgl_bapnaik` varchar(100) NOT NULL,
  `tgl_terbitbap` varchar(100) NOT NULL,
  `jumlah_bap` int(11) NOT NULL,
  `no_seri` varchar(100) NOT NULL,
  `keterangan` longtext NOT NULL,
  PRIMARY KEY (`id_monitoring`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data untuk tabel `monitoring`
--


-- --------------------------------------------------------

--
-- Struktur dari tabel `no_transaksi`
--

CREATE TABLE IF NOT EXISTS `no_transaksi` (
  `id_nomortransaksi` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_nomortransaksi` varchar(30) NOT NULL,
  `tupoksi_kts` varchar(30) NOT NULL,
  `jumlah_nomortransaksi` int(11) NOT NULL,
  PRIMARY KEY (`id_nomortransaksi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `no_transaksi`
--

INSERT INTO `no_transaksi` (`id_nomortransaksi`, `jenis_nomortransaksi`, `tupoksi_kts`, `jumlah_nomortransaksi`) VALUES
(1, 'pengajuan', '-1.811.111', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `id_pegawai` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(100) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `bagian_pegawai` varchar(100) NOT NULL,
  `jabatan_pegawai` varchar(100) NOT NULL,
  `status_pegawai` int(11) NOT NULL,
  PRIMARY KEY (`id_pegawai`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nip`, `nama_pegawai`, `bagian_pegawai`, `jabatan_pegawai`, `status_pegawai`) VALUES
(1, '19600507 198503 1 011', 'Utang Sopyandi', 'Penguji', 'Ketua Tim', 0),
(2, '19820713 201001 1 024', 'Arie Fitriadi, ST', 'Penguji', 'Anggota Tim', 0),
(3, '19760630 200701 1 017', 'Rahardian', 'Penguji', 'Anggota Tim', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengajuan`
--

CREATE TABLE IF NOT EXISTS `pengajuan` (
  `id_pengajuan` int(11) NOT NULL AUTO_INCREMENT,
  `no_pengajuan` longtext NOT NULL,
  `id_perusahaan` int(11) NOT NULL,
  `perihal_pengajuan` longtext NOT NULL,
  `tgl_pengajuan` varchar(20) NOT NULL,
  `status_pengajuan` int(11) NOT NULL,
  `disposisi` int(11) NOT NULL,
  `status_unit` int(11) NOT NULL,
  `status_spt` int(11) NOT NULL,
  `kasie_a` int(11) NOT NULL,
  `tglkasie_a` varchar(100) NOT NULL,
  `kabid_a` int(11) NOT NULL,
  `tglkabid_a` varchar(100) NOT NULL,
  `status_cek` int(11) NOT NULL,
  `kasie_b` int(11) NOT NULL,
  `tglkasie_b` date NOT NULL,
  `kabid_b` int(11) NOT NULL,
  `tglkabid_b` date NOT NULL,
  PRIMARY KEY (`id_pengajuan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data untuk tabel `pengajuan`
--


-- --------------------------------------------------------

--
-- Struktur dari tabel `perusahaan`
--

CREATE TABLE IF NOT EXISTS `perusahaan` (
  `id_perusahaan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_perusahaan` longtext NOT NULL,
  `jenis_perusahaan` longtext NOT NULL,
  `alamat_perusahaan` longtext NOT NULL,
  `penanggung_jawab` varchar(100) NOT NULL,
  `telp_perusahaan` longtext NOT NULL,
  `telp_perusahaan2` varchar(100) NOT NULL,
  `telp_perusahaan3` varchar(100) NOT NULL,
  `fax_perusahaan` varchar(100) NOT NULL,
  `status_perusahaan` int(11) NOT NULL,
  PRIMARY KEY (`id_perusahaan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data untuk tabel `perusahaan`
--

INSERT INTO `perusahaan` (`id_perusahaan`, `nama_perusahaan`, `jenis_perusahaan`, `alamat_perusahaan`, `penanggung_jawab`, `telp_perusahaan`, `telp_perusahaan2`, `telp_perusahaan3`, `fax_perusahaan`, `status_perusahaan`) VALUES
(1, 'CV. ANUGERAH KARYA MANDIRI', 'KAROSERI', 'Jl. Pelopor IV No. 17 RT. 01/05 Tegal Alur Kalideres Jakarta\r\n', 'YACOBU SUGIHARTO', '55959140', '55955452', '', '55963272', 0),
(2, 'CV. BAGUS JAYA', 'KAROSERI', 'Jl. Garuda Gg. Mangga No. 1 Kemayoran Jakarta\r\n', 'YUWITA, SE', '4243864', '82431446', '8250373', '8250425', 0),
(3, 'CV. CITRA MANGGALA KARYA', 'KAROSERI', 'Jl. Raya Daan Mogot KM. 10 No. 5 Jakarta Barat\r\n', 'FRANGKY', '5455088', '5455089', '', '5417338', 0),
(4, 'CV. SANTAM TRAILINDO JAKARTA', 'KAROSERI', 'Jl. Raya Cakung No. 36 A Cilincing Jakarta Utara\r\n', 'ILYAS BAKHRI HAFIZD', '44830546', '', '', '44830546', 0),
(5, 'CV. YANATTA USAHA MANDIRI', 'KAROSERI', 'Jl. Raya Lebak Bulus N+o. 53, Jakarta Selatan\r\n', 'RAMONA', '', '', '', '', 0),
(6, 'KARYA TEKNIK SERVICE', 'KAROSERI', 'Jl. Kapuk Muara No. 1 - 2  Jakarta\r\n', 'SUGANDA JENY', '5406325', '5455502', '9156575', '5406325', 0),
(7, 'PT. ABILINDO LINTAS PERSADA', 'KAROSERI', 'Jl. Ganggeng III No. 14 Sungai Bambu, Tanjung Priok - Jakarta\r\n', 'YOHANES. S', '43936079', '', '', '43936086', 0),
(8, 'PT. ADHIKARISMA PRATAMA', 'KAROSERI', 'Jl. Tipar Cakung KM. 23 No. 20  Jakarta\r\n', 'Ir. ANDIYANTO WARDHANA', '46835427', '46835428', '', '46835430', 0),
(9, 'PT. ADICITRA BHIRAWA', 'KAROSERI', 'Jl. Raya Pegangsaan Dua No. 88 Jakarta\r\n', 'F.X. SUSANTO', '44837033', '', '', '44837036', 0),
(10, 'PT. AMAN SINAMBUNG KARYA', 'KAROSERI', 'Jl. Samanhudi No. 20 Lt II Jakarta Pusat\r\n', 'RINI GUNAWAN', '3840703', '655555', '', '654555', 0),
(11, 'PT. ANTIKA RAYA NIAGANUSA', 'KAROSERI', 'Jl. Raya Cakung Cilincing KM.1,23 Jakarta\r\n', 'FERRY TENACIUS', '4611717', '', '', '4613838', 0),
(19, 'PT. BUMINDO GASUTAMA', 'KAROSERI', 'Jl. Agung Utara Raya Blok M No. 58-59 Taman Nyiur, Sunter Podomoro, Jakarta\r\n', 'Agus Suryanto', '65831008', '8646688', '', '6504465', 0),
(18, 'PT. BUANA PAKSI ABADI', 'KAROSERI', 'Jl. Raya Setu RT.004/001 Cipayung Jakarta\r\n', 'DIAN HADI', '84974987', '', '', '84974987', 0),
(17, 'PT. BOC GASES INDONESIA', 'KAROSERI', 'Jl. Raya Bekasi KM 21 Pulogadung Jakarta\r\n', 'AGUS DWI PUTRANTO', '4601793', '4602785', '', '4602789', 0),
(16, 'PT. ANUGRAH CITRA REKONINDO', 'KAROSERI', 'Jl. Raya Bekasi Cakung Km.23 Jakarta\r\n', 'RUSMINO', '46824422', '46824433', '46825015', '', 0),
(20, 'PT. CAKRA INFOTIKA CITRANUSA', 'KAROSERI', 'Jl. Jatibarang V/39 Rawamangun Jakarta Timur\r\n', 'INA MARFIANI, SE, MM', '4892593', '4890636', '', '4892593', 0),
(21, 'PT. CENTRAL AUTO COMPERINDO', 'KAROSERI', 'Jl. Raya Bogor Km.19/39 Kramat Jati Jakarta\r\n', 'Drs. RADMAN HARTONO', '86860130', '86861602', '', '8672126', 0),
(22, 'PT. Sumber Teknik Service', 'Karoseri', 'Jl. Kapuk Utara 14460', 'Joko', '09890790', '0709879', '097097', '09709870', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `sk`
--

CREATE TABLE IF NOT EXISTS `sk` (
  `id_sk` int(11) NOT NULL AUTO_INCREMENT,
  `no_sk` varchar(30) NOT NULL,
  `tgl_sk` varchar(20) NOT NULL,
  `foh_sk` varchar(100) NOT NULL,
  `roh_sk` varchar(100) NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `status_sk` int(11) NOT NULL,
  PRIMARY KEY (`id_sk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `sk`
--

INSERT INTO `sk` (`id_sk`, `no_sk`, `tgl_sk`, `foh_sk`, `roh_sk`, `id_jenis`, `status_sk`) VALUES
(1, '3647/AJ.410/DRJD/2012', '27-09-2012', '', '', 1, 0),
(2, '3652/AJ.402/DRJD/2009', '09-11-2009', '', '', 2, 0),
(3, '2324/AJ.402/DRJ/2007', '20-06-2007', '', '', 3, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `spt`
--

CREATE TABLE IF NOT EXISTS `spt` (
  `id_spt` int(11) NOT NULL AUTO_INCREMENT,
  `no_spt` varchar(100) NOT NULL,
  `tgl_spt` varchar(100) NOT NULL,
  `status_spt` int(11) NOT NULL,
  `id_pengajuan` int(11) NOT NULL,
  PRIMARY KEY (`id_spt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data untuk tabel `spt`
--


-- --------------------------------------------------------

--
-- Struktur dari tabel `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `nama_type` varchar(30) NOT NULL,
  `id_merk` int(11) NOT NULL,
  `status_type` int(11) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `type`
--

INSERT INTO `type` (`id_type`, `nama_type`, `id_merk`, `status_type`) VALUES
(1, '110 ST LONG', 1, 0),
(2, '110 ET', 1, 0),
(3, 'L300', 2, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `id_unit` int(11) NOT NULL AUTO_INCREMENT,
  `chasis` varchar(100) NOT NULL,
  `engine` varchar(100) NOT NULL,
  `ket` varchar(100) NOT NULL,
  `status_unit` int(11) NOT NULL,
  `jumlah_ujiunit` int(11) NOT NULL,
  PRIMARY KEY (`id_unit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data untuk tabel `unit`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
