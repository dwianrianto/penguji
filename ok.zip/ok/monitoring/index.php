<meta http-equiv="refresh" content="7;URL=index.php">


<!DOCTYPE html>
<html>


<body bgcolor="#3399CC">

			<center>
			<table width="814">
  <tr>
					<td width="56" height="44"><img src="../2.png" width="56" height="60" /></td>
	  <td width="746">
<center>
							<font color="#FFFFFF"><h3>LAPORAN PENELITIAN DAN PENILAIAN FISIK KENDARAAN BERMOTOR	<br/>														
									SEKSI KESELAMATAN DAN TEKHNIS SARANA							
							</h3></font>
                    </center>
				  </td>
			  </tr>
			</table>
	
</center>
			
<iframe width="100%" height="650px" src="isi.php" bgcolor="white">
 
</iframe>
			
<div class="marqueeart2">
<div style="font-size:17px;color:black;text-shadow:2px 2px 4px #000;font-family:Times New Roman;padding-top:5px;">
	<center>
LAPORAN PENELITIAN DAN PENILAIAN FISIK KENDARAAN BERMOTOR														
SEKSI KESELAMATAN DAN TEKHNIS SARANA
	</center>
</div>
<style>
.marqueeart2 {width:100%;height:30px;background-color:#a19eab;
filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0, startColorstr='lightblue', endColorstr='lightblue');
background-image:-webkit-linear-gradient(top, #0066CC 0%, #fcfcfc 50%, #0066CC 100%);
background-image:-moz-linear-gradient(top, #0066CC 0%, #fcfcfc 50%, #0066CC 100%);
background-image:-ms-linear-gradient(top, #0066CC 0%, #fcfcfc 50%, #0066CC 100%);
background-image:-o-linear-gradient(top, #0066CC 0%, #fcfcfc 50%, #0066CC 100%);
  background-image:linear-gradient(top, #0066CC 0%, #fcfcfc 50%, #0066CC 100%);
}
</style>

</html>