<?php
	$con = mysql_connect('localhost','root','');
?>