<?php
    $servername="localhost";
    $username="root";
    $password="";
    $database="pengujian";
    $koneksi=mysql_connect ($servername, $username, $password);

  if ($koneksi) {
    mysql_select_db ($database) or die ("Database Tidak Ditemukan");
   
   } else {
     echo "<b> Koneksi Gagal </b>";
   }

?>