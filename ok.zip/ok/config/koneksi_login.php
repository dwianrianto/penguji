<?

# cek apakah username dan password sudah diisi
if(!empty($_POST["namad"]) and !empty($_POST["password"])){

#panggil file koneksi
include "koneksi.php";

$sql_pmhn = "select * from login_user where namad = '$_POST[namad]' and password = '$_POST[password]' and level='user'";
$q_pmhn = mysql_query($sql_pmhn);
$data_pmhn = mysql_fetch_array($q_pmhn);

$sql_adm = "select * from login_admin where namad = '$_POST[namad]' and  password= '$_POST[password]' and level='admin'";
$q_adm = mysql_query($sql_adm);
$data_adm = mysql_fetch_array($q_adm);

if($_POST["namad"] == $data_pmhn["namad"] and $_POST["password"] == $data_pmhn["password"])
{
session_register("user");
$_SESSION["namad"] = $data_pmhn["namad"];

header("location:user/index.php.php?p=1");
}else{

if($_POST["namad"] == $data_adm["namad"] and $_POST["password"] == $data_adm["password"])
{
session_register("admin");
$_SESSION["namad"] = $data_adm["namad"];

header("location:admin/admin.php?p=1");
}else{

?>
<script type="text/javascript">alert("Maaf Username atau Password anda salah...!");
document.location='../index.php?p=3';
</script>
<?
}
}
}
}
}
}else{
?>
<script type="text/javascript">alert("Maaf Username dan Password harus diisi...!");
document.location='../index.php?note=empty';
</script>
<?
}
?>