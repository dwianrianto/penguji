<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$id_jenis=$_POST['id_jenis'];
$no_sk=$_POST['no_sk'];
$tgl_sk=$_POST['tgl_sk'];
$foh=$_POST['foh'];
$roh=$_POST['roh'];

$query=mysql_query("insert into sk
(id_jenis,no_sk,tgl_sk,foh_sk,roh_sk)
	 values 
('$id_jenis','$no_sk','$tgl_sk','$foh','$roh')") or die(mysql_error());


if ($query){

	?>
		<div class="alert bg-info" role="alert">
                        	<center>
					<span class="glyphicon glyphicon-exclamation-sign"></span> SK Baru Berhasil di Simpan  ...
				</div>
<?php 
	}
	else{
		echo"gagal";
		}
		}
?>



<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->




<a href="?page=pages/master">
							<button class="btn btn-sm btn-danger"> Back to Master </button>
								</a>
                                
                                
<h3>
	Tambah SK Baru
</h3>


<form class="form-horizontal" role="form" action="" method="post">
									<div class="form-group">
                                    
                                    	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Unit </label>

										<div class="col-sm-9">
                                        <link rel="stylesheet" href="chosens.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>
											<select name="id_jenis" id="namad" data-placeholder="Choose a Country..." class="chosen-select" style="width:350px;" tabindex="2" required="required">
															<option value="">Pilih Unit Kendaraan</option>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select
																  						jenis.*,
																  						type.*,
																						merk.*
																						from jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk");
																  while($data=mysql_fetch_array($query)){  
																?>
										<option value="<?php echo $data['id_jenis']; ?>">
											<?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?> <?php echo $data['nama_jenis']; ?>
                                        </option>
																<?php $no++;}?>
											</select>
     <script src="../assets/js/jquery.min.js" type="text/javascript"></script>
  <script src="chosens.js" type="text/javascript"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>			                                       
                                            
										</div>
										<br/><br/><br/>
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> No. SK </label>

										<div class="col-sm-9">
											<input type="text" name="no_sk" id="form-field-1" placeholder="No. SK" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
                                        
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tanggal SK </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="tgl_sk" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" autocomplete="off" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
											<br/><br/>
										
									</div>
                                    
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> FOH </label>

										<div class="col-sm-9">
											<input type="number" name="foh" id="form-field-1" placeholder="FOH" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
                                        
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> ROH </label>

										<div class="col-sm-9">
											<input type="number" name="roh" id="form-field-1" placeholder="ROH" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>

           </form>
           
           <link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Merk</th>
                <th>Type</th>
                <th>Jenis</th>
                <th>Konstruksi</th>
				<th>No. SK</th>
                <th>Tgl SK</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select
																  						sk.*,
																  						jenis.*,
																  						type.*,
																						merk.*
																						from sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?></td>
                <td><?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?></td>
                <td><?php echo $data['nama_konstruksi']; ?></td>
				<td><?php echo $data['no_sk']; ?></td>
                <td><?php echo $data['tgl_sk']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>