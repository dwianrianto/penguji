<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$no_pengajuan=$_POST['no_pengajuan'];
$tgl_pengajuan=$_POST['tgl_pengajuan'];
$perihal=$_POST['perihal'];
$id_perusahaan=$_POST['id_perusahaan'];

$query=mysql_query("insert into pengajuan
(no_pengajuan,id_perusahaan,perihal_pengajuan,tgl_pengajuan)
	 values 
('$no_pengajuan','$id_perusahaan','$perihal','$tgl_pengajuan')") or die(mysql_error());


if ($query){

	?>
		<script>document.location='index.php?page=pages/pilihpengajuan';</script>
<?php 
	}
	else{
		echo"gagal";
		}
		}
?>


<!DOCTYPE html>
<html>
<head>
<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getuser.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>


<form method="POST" action="">
			<h3>
		Input Pengajuan
			</h3>
			<hr/>
			
		
		
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> No. Pengajuan </label>

										<div class="col-sm-9">
											<input type="text" name="no_pengajuan" id="form-field-1" placeholder="No. Pengajuan" class="col-xs-10 col-sm-5" autocomplete="off" />
										</div>
											<br/><br/>
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tanggal Pengajuan </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="tgl_pengajuan" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" autocomplete="off" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
											<br/><br/>
											
										<label name="perihal" class="col-sm-3 control-label no-padding-right" for="form-field-1"> Perihal </label>

										<div class="col-sm-9">
											<input type="text" name="perihal" id="form-field-1" placeholder="Perihal" class="col-xs-10 col-sm-5" />
										</div>
											<br/><br/>
											<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Perusahaan
																	</label>
						<div class="col-sm-9">
		<link rel="stylesheet" href="chosens.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>
          <select name="id_perusahaan" onchange="showUser(this.value)" data-placeholder="Choose a Country..." class="chosen-select" required="required">
<option value="">Select a person:</option>
	<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from perusahaan");
																  while($row=mysql_fetch_array($query)){  
																?>
<option value="<?php echo $row['id_perusahaan']; ?>"><?php echo $row['nama_perusahaan']; ?> <?php echo $row['jenis_perusahaan']; ?></option>
	<?php
}
		
?>
</select>
					
		  
		  
  <script src="../assets/js/jquery.min.js" type="text/javascript"></script>
  <script src="chosens.js" type="text/javascript"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>				<br/><br/>
									</div>	
										</div>

<br/><br/><br/>
<div id="txtHint"><b>Person info will be listed here.</b></div>

<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
										
</form>

</body>
</html>