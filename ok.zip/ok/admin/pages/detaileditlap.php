<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$id_monitoring=$_POST['id_monitoring'];
$l1=$_POST['l1'];
$l2=$_POST['l2'];
$l3=$_POST['l3'];
$l4=$_POST['l4'];
$l5=$_POST['l5'];
$l6=$_POST['l6'];
$l7=$_POST['l7'];
$l8=$_POST['l8'];
$l9=$_POST['l9'];
$l10=$_POST['l10'];
$l11=$_POST['l11'];
$l12=$_POST['l12'];
$l13=$_POST['l13'];
$l14=$_POST['l14'];
$l15=$_POST['l15'];

$query=mysql_query("update monitoring set id_perusahaan='$l1',
										  nomor_p='$l2',
										  tgl_p='$l3',
										  jumlah_k='$l4',
										  no_spt='$l5',
										  tgl_spt='$l6',
										  tgl_cek='$l7',
										  petugas='$l8',
										  jumlah_lulus='$l9',
										  jumlah_tlulus='$l10',
										  tgl_bapnaik='$l11',
										  tgl_terbitbap='$l12',
										  jumlah_bap='$l13',
										  no_seri='$l14',
										  keterangan='$l15' where id_monitoring='$id_monitoring'") or die(mysql_error());


if ($query){

	?>
		<script>document.location='index.php?page=pages/editlaporan';</script>
<?php 
	}
	else{
		echo"gagal";
		}
		}
?>

			<div class="btn-group">
												<button class="btn btn-sm btn-info"><i class="ace-icon fa fa-cog"></i>Data Laporan</button>

												<button data-toggle="dropdown" class="btn btn-sm btn-info dropdown-toggle">
													<i class="ace-icon fa fa-angle-down icon-only"></i>
												</button>

												<ul class="dropdown-menu dropdown-yellow">
													<li>
														<a href="?page=pages/inputlaporan"><i class="ace-icon glyphicon glyphicon-plus"></i>Tambah Laporan</a>
													</li>

													<li>
														<a href="?page=pages/editlaporan"><i class="ace-icon fa fa-pencil-square-o"></i>Edit Laporan</a>
													</li>
												</ul>
							</div><!-- /.btn-group -->


<h3>
	Data Perusahaan Baru
</h3>


<form class="form-horizontal" role="form" action="" method="post">

						<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("SELECT
  `pengujian`.`monitoring`.`id_perusahaan`,
  `pengujian`.`monitoring`.*,
  `pengujian`.`perusahaan`.*
FROM
  `pengujian`.`monitoring`
  INNER JOIN `pengujian`.`perusahaan`
    ON `pengujian`.`monitoring`.`id_perusahaan` =
    `pengujian`.`perusahaan`.`id_perusahaan` where monitoring.id_monitoring='$id'");
																  $eachRecord=mysql_fetch_array($query);
																?>

									<div class="form-group">
											<input type="hidden" name="id_monitoring" value="<?php echo $eachRecord['id_monitoring'];?>" />
			<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Perusahaan &nbsp;&nbsp;&nbsp;&nbsp;
																	</label>
						
		<link rel="stylesheet" href="chosens.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>						
										<select name="l1" data-placeholder="Choose a Country..." class="chosen-select" style="width:350px;" tabindex="2" required="required">
												<option value="<?php echo $eachRecord['id_perusahaan']; ?>"><?php echo $eachRecord['nama_perusahaan']; ?></option>
														<?php
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from perusahaan");
																  while($data=mysql_fetch_array($query)){  
																?>
												<option value="<?php echo $data['id_perusahaan']; ?>"><?php echo $data['nama_perusahaan']; ?></option>
															<?php } ?>
											  </select>
												<br/><br/>
			<script src="../assets/js/jquery.min.js" type="text/javascript"></script>
  <script src="chosens.js" type="text/javascript"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>				
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor Pengajuan </label>

										<div class="col-sm-9">
											<input type="text" value="<?php echo $eachRecord['nomor_p'];?>" name="l2" id="form-field-1" placeholder="Nomor Pengajuan" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tanggal Pengajuan </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="l3" value="<?php echo $eachRecord['tgl_p'];?>" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Jumlah Kendaraan </label>

										<div class="col-sm-9">
											<input type="number" value="<?php echo $eachRecord['jumlah_k'];?>" name="l4" id="form-field-1" placeholder="Jumlah Kendaraan" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor SPT </label>

										<div class="col-sm-9">
											<input type="text" value="<?php echo $eachRecord['no_spt'];?>" name="l5" id="form-field-1" placeholder="Nomor Spt" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tgl SPT </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="l6" value="<?php echo $eachRecord['tgl_spt'];?>" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tgl Cek </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="l7" value="<?php echo $eachRecord['tgl_cek'];?>" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Petugas </label>

										<div class="col-sm-9">
											<input type="text" value="<?php echo $eachRecord['petugas'];?>" name="l8" id="form-field-1" placeholder="Username" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Jumlah Lulus </label>

										<div class="col-sm-9">
											<input type="number" value="<?php echo $eachRecord['jumlah_lulus'];?>" name="l9" id="form-field-1" placeholder="Jumlah Lulus" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Jumlah Tidak Lulus </label>

										<div class="col-sm-9">
											<input type="number" value="<?php echo $eachRecord['jumlah_tlulus'];?>" name="l10" id="form-field-1" placeholder="Jumlah Tidak Lulus" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tgl BAP Naik </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="l11" value="<?php echo $eachRecord['tgl_bapnaik'];?>" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tgl Terbit BAP </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="l12" value="<?php echo $eachRecord['tgl_terbitbap'];?>" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Jumlah BAP </label>

										<div class="col-sm-9">
											<input type="number" value="<?php echo $eachRecord['jumlah_bap'];?>" name="l13" id="form-field-1" placeholder="Jumlah Lulus" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor Seri </label>

										<div class="col-sm-9">
											<input type="text" value="<?php echo $eachRecord['no_seri'];?>" name="l14" id="form-field-1" placeholder="Nomor Seri" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Keterangan </label>

										<div class="col-sm-9">
											<input type="text" value="<?php echo $eachRecord['keterangan'];?>" name="l15" id="form-field-1" placeholder="Keterangan" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										
									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
