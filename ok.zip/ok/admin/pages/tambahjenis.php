<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$id_type=$_POST['id_type'];
$nama_jenis=$_POST['nama_jenis'];
$nama_konstruksi=$_POST['nama_konstruksi'];

$query=mysql_query("insert into jenis
(id_type,nama_jenis,nama_konstruksi)
	 values 
('$id_type','$nama_jenis','$nama_konstruksi')") or die(mysql_error());


if ($query){

	?>
		<div class="alert bg-info" role="alert">
                        	<center>
					<span class="glyphicon glyphicon-exclamation-sign"></span> Jenis Baru Berhasil di Simpan  ...
				</div>
<?php 
	}
	else{
		echo"gagal";
		}
		}
?>

<script type="text/javascript" src="register/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$("#namad").click(function() {
var namad = $('#namad').val();
if(namad=="")
{
$("#disp").html("");
}
else
{
$.ajax({
type: "POST",
url: "register/validate2.php",
data: "namad="+ namad ,
success: function(html){
$("#disp").html(html);
}
});
return false;
}
});
});
</script>

<a href="?page=pages/master">
							<button class="btn btn-sm btn-danger"> Back to Master </button>
								</a>
                                
                                
<h3>
	Tambah Jenis Baru
</h3>


<form class="form-horizontal" role="form" action="" method="post">
									<div class="form-group">
                                    
                                    	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Merk </label>

										<div class="col-sm-9">
											<select name="id_merk" id="namad" data-placeholder="Choose a Country..." style="width:350px;" tabindex="2" required="required">
															<option value="">Pilih Merk</option>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from merk");
																  while($data=mysql_fetch_array($query)){  
																?>
										<option value="<?php echo $data['id_merk']; ?>"><?php echo $data['nama_merk']; ?></option>
																<?php $no++;}?>
											</select>
                                            
                                            
										</div>
										<br/><br/><br/>
                                        
                                        
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Type </label>
                                        <div class="col-sm-9">
											
                                            	<div id="disp">--- Pilih Merk ---</div>
                                            
										</div>
										<br/><br/><br/>
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Jenis </label>

										<div class="col-sm-9">
											<input type="text" name="nama_jenis" id="form-field-1" placeholder="Jenis" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
                                        
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Konstruksi </label>

										<div class="col-sm-9">
											<input type="text" name="nama_konstruksi" id="form-field-1" placeholder="Konstrksi" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>

           </form>
           
           
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

												<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
													<thead>
														<tr>
                                                        	<th><b>Merk</b></th>
                                                            <th><b>Type</b></th>
															<th><b>Jenis</b></th>
                                                            <th><b>Konstruksi</b></th>
														</tr>
													</thead>

													<tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select
																  						jenis.*,
																  						type.*,
																						merk.*
																						from jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																						");
																  while($data=mysql_fetch_array($query)){  
																 ?>
														<tr>
                                                        	<td><?php echo $data['nama_merk'] ?></td>
                                                            <td><?php echo $data['nama_type'] ?></td>
															<td><?php echo $data['nama_jenis'] ?></td>
                                                            <td><?php echo $data['nama_konstruksi'] ?></td>
														</tr>
																<?php $no++;}?>
													</tbody>
												</table>