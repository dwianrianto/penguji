<?php
	include"../config/koneksi.php";
	
	
		$query=mysql_query("update monitoring set status_monitoring='1'");
?>

<script>javascript:history.go(-1)</script>