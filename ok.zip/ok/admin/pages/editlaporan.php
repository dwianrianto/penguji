<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
	
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<body>
		<h3>
        	Data di Tampilkan
        </h3>
        	<hr/>
								<div class="btn-group">
												<button class="btn btn-sm btn-info"><i class="ace-icon fa fa-cog"></i>Data Laporan</button>

												<button data-toggle="dropdown" class="btn btn-sm btn-info dropdown-toggle">
													<i class="ace-icon fa fa-angle-down icon-only"></i>
												</button>

												<ul class="dropdown-menu dropdown-yellow">
													<li>
														<a href="?page=pages/inputlaporan"><i class="ace-icon glyphicon glyphicon-plus"></i>Tambah Laporan</a>
													</li>

													<li>
														<a href="?page=pages/editlaporan"><i class="ace-icon fa fa-pencil-square-o"></i>Edit Laporan</a>
													</li>
												</ul>
							</div><!-- /.btn-group -->
                            
                            <div class="btn-group">
												<button class="btn btn-sm btn-info"><i class="ace-icon fa fa-cog"></i>Print Laporan</button>

												<button data-toggle="dropdown" class="btn btn-sm btn-info dropdown-toggle">
													<i class="ace-icon fa fa-angle-down icon-only"></i>
												</button>

												<ul class="dropdown-menu dropdown-yellow">
													<li>
														<a href="?page=pages/rekap"><i class="ace-icon glyphicon glyphicon-plus"></i>Rekap</a>
													</li>
												</ul>
							</div><!-- /.btn-group -->
                            
                            <div class="btn-group">
												<button class="btn btn-sm btn-info"><i class="ace-icon fa fa-cog"></i>Data Tersimpan</button>

												<button data-toggle="dropdown" class="btn btn-sm btn-info dropdown-toggle">
													<i class="ace-icon fa fa-angle-down icon-only"></i>
												</button>

												<ul class="dropdown-menu dropdown-yellow">
													<li>
														<a href="?page=pages/datatersimpan"><i class="ace-icon glyphicon glyphicon-plus"></i>View</a>
													</li>
												</ul>
							</div><!-- /.btn-group -->
                            
                            
								<br/><br/>
                                
                                Export to Exel <a href="javascript:;" ><img src="excel-icon.jpeg" width="18" height="18" border="0" onClick="window.open('./excel/export_excel.php','scrollwindow','top=200,left=300,width=800,height=500');"></a>
                                		------
                                <a href="?page=pages/prosespindah" onClick="return confirm('Apakah Anda Yakin Untuk Memindahkan ke Data Tersimpan ?');">
                                	<button class="btn-primary">Pindahkan ke Data Tersimpan</button>
                                </a>
                                	<br/><br/>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
			<th width="2%">No.</th>
			<th width="2%">Perusahaan</th>
			<th width="16%">No. Pengajuan</th>
			<th width="16%">Tgl Pengajuan</th>
			<th width="12%">Jumlah Kendaraan</th>
			<th width="20%">No. Spt</th>
			<th width="18%">Tgl Spt</th>
			<th width="14%">Tgl Cek</th>
			<th width="14%">Jumlah Lulus</th>
			<th width="14%">Jumlah Tidak Lulus</th>
			<th width="14%">Tgl BAP Naik</th>
			<th width="14%">Tgl BAP Terbit</th>
			<th width="14%">Julah BAP</th>
			<th width="14%">No. Seri</th>
			<th width="14%">Ket</th>
			<th width="14%">Action</th>
			</tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("SELECT
  monitoring.id_perusahaan,
  monitoring.*,
  perusahaan.*
FROM
  monitoring
  INNER JOIN perusahaan
    ON monitoring.id_perusahaan =
    perusahaan.id_perusahaan where monitoring.status_monitoring='0'");
																  while($eachRecord=mysql_fetch_array($query)){  
																?>
            <tr>
			<td><?php echo $no; ?></td>
			<td class="fname"><?php echo $eachRecord['nama_perusahaan'];?></td>
			<td class="lname"><?php echo $eachRecord['nomor_p'];?></td>
			<td class="tech"><?php echo $eachRecord['tgl_p'];?></td>
			<td class="email"><?php echo $eachRecord['jumlah_k'];?></td>
			<td class="address"><?php echo $eachRecord['no_spt'];?></td>
			<td class="fname"><?php echo $eachRecord['tgl_spt'];?></td>
			<td class="lname"><?php echo $eachRecord['tgl_cek'];?></td>
			<td class="tech"><?php echo $eachRecord['jumlah_lulus'];?></td>
			<td class="email"><?php echo $eachRecord['jumlah_tlulus'];?></td>
			<td class="address"><?php echo $eachRecord['tgl_bapnaik'];?></td>
			<td class="address"><?php echo $eachRecord['tgl_terbitbap'];?></td>
			<td class="address"><?php echo $eachRecord['jumlah_bap'];?></td>
			<td class="address"><?php echo $eachRecord['no_seri'];?></td>
			<td class="address"><?php echo $eachRecord['keterangan'];?></td>
			<td>
					<a href="?page=pages/detaileditlap&id=<?php echo $eachRecord['id_monitoring']; ?>">
				Edit
					</a>
				|| 
					<a href="?page=pages/deletelap&id=<?php echo $eachRecord['id_monitoring']; ?>" onClick="return confirm('Apakah Anda Ingin Menghapus Laporan Ini ?');">Delete</a>
			</td>
			</tr>
																<?php $no++;}?>
        </tbody>
    </table>
	</body>