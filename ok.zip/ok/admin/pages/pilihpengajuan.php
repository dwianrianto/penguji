
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
	
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<body>

		<h4>
        	Input Unit Kendaraan
        </h4>
        	<hr/>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th>Nama Perusahaan</th>
                <th>No. Pengajuan</th>
                <th>Perihal</th>
				<th>Tgl Pengajuan</th>
				<th>Telp</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("SELECT
  `pengajuan`.*,
   `perusahaan`.*,
   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`
FROM
   `pengajuan`
  LEFT JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
    =  `perusahaan`.`id_perusahaan` where pengajuan.status_unit='0' AND pengajuan.status_spt='0'");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?>. <?php echo $data['nama_perusahaan']; ?></td>
                <td><?php echo $data['no_pengajuan']; ?></td>
                <td><?php echo $data['perihal_pengajuan']; ?></td>
				<td><?php echo $data['tgl_pengajuan']; ?></td>
				<td><?php echo $data['telp_perusahaan']; ?></td>
                <td>
						<a href="?page=pages/inputunit&id=<?php echo $data['id_pengajuan']; ?>">
							<button class="btn btn-sm btn-info"><i class="ace-icon glyphicon glyphicon-plus"></i>Input Unit</button>
								</a>
				</td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
	</body>