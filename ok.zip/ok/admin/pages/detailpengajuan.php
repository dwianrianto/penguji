<!DOCTYPE html>
<html>
<head>

<script type="text/javascript" src="register/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$("#namad").keyup(function() {
var namad = $('#namad').val();
if(namad=="")
{
$("#disp").html("");
}
else
{
$.ajax({
type: "POST",
url: "register/validate.php",
data: "namad="+ namad ,
success: function(html){
$("#disp").html(html);
}
});
return false;
}
});
});
</script>



</head>
<body>

	<h4>
		Detail Pengajuan
	</h4>
    
					
					
								<a href="?page=pages/canselpegajuan&id=<?php echo $id=$_GET['id']; ?>">
							<button class="btn btn-sm btn-danger"><i class="ace-icon glyphicon glyphicon-pencil"></i>Cansel Pengajuan</button>
								</a>
		<hr/>
        
		
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
																		   `pengajuan`.*,
																		   `perusahaan`.*,
																		   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`
																		FROM
																		   `pengajuan`
																		  LEFT JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
																			=  `perusahaan`.`id_perusahaan` where id_pengajuan='$id'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Nama Perusahaan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_perusahaan']; ?></font>
																	</div>
																<br/><br/>
																				<input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_pengajuan']; ?></font>
																	</div>
                                        
                                        
                                        
			<br/><br/><br/>
					
					

<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Merk/Type</th>
                <th>Jenis/Konstruksi</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_pengajuan='$id'
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
                <td><?php echo $no; ?>. <?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?> / <?php echo $data['nama_konstruksi']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>