<?php

include "../../config/koneksi.php";

$id=$_POST['id'];

$cek=mysql_query("select jumlah_nomortransaksi,tupoksi_kts from no_transaksi");
$dap=mysql_fetch_array($cek);
$r=$dap['jumlah_nomortransaksi']+1;

$nomor=$r.'/'.$dap['tupoksi_kts'];

$query=mysql_query("insert into spt
(no_spt,tgl_spt,id_pengajuan)
	 values 
('$nomor','$tgl_spt','$id')") or die(mysql_error());

$query3=mysql_query("update no_transaksi set jumlah_nomortransaksi='$r'") or die(mysql_error());

$query4=mysql_query("update pengajuan set status_spt='1' where id_pengajuan='$id'") or die(mysql_error());

?>

<script>document.location='../index.php?page=pages/dataspt';</script>