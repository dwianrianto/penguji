<?php

include "../config/koneksi.php";

$id=$_GET['id'];

$query3=mysql_query("update pengajuan set status_unit='1' where id_pengajuan='$id'") or die(mysql_error());

?>

<script>document.location='index.php?page=pages/buatspt';</script>