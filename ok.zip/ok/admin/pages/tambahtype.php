<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$nama_type=$_POST['nama_type'];
$id_merk=$_POST['id_merk'];

$query=mysql_query("insert into type
(nama_type,id_merk)
	 values 
('$nama_type','$id_merk')") or die(mysql_error());


if ($query){

	?>
		<div class="alert bg-info" role="alert">
                        	<center>
					<span class="glyphicon glyphicon-exclamation-sign"></span> Type Baru Berhasil di Simpan  ...
                    		</center>
				</div>
<?php 
	}
	else{
		echo"gagal";
		}
		}
?>

<a href="?page=pages/master">
							<button class="btn btn-sm btn-danger"> Back to Master </button>
								</a>
                                
<h3>
	Tambah Type Baru
</h3>


<form class="form-horizontal" role="form" action="" method="post">
									<div class="form-group">
									
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Merk </label>

										<div class="col-sm-9">
  <link rel="stylesheet" href="chosens.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>
                                        <select name="id_merk" data-placeholder="Choose a Country..." class="chosen-select" style="width:350px;" tabindex="2" required="required">
															<option value="">Pilih Merk</option>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from merk");
																  while($data=mysql_fetch_array($query)){  
																?>
										<option value="<?php echo $data['id_merk']; ?>"><?php echo $data['nama_merk']; ?></option>
																<?php $no++;}?>
											</select>
                                            
   
  <script src="../assets/js/jquery.min.js" type="text/javascript"></script>
  <script src="chosens.js" type="text/javascript"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>				
										</div>
										<br/><br/><br/>
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nama Type </label>

										<div class="col-sm-9">
											<input type="text" name="nama_type" id="form-field-1" placeholder="Type" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										
										
										
										
										
									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
</form>
                                    
                                    
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

												<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
													<thead>
														<tr>
															<th><b>Merk</b></th>
                                                            <th><b>Type</b></th>
                                                            <th>Status</th>
                											<th>Action</th>
														</tr>
													</thead>

													<tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select
																  						type.*,
																						merk.*
																						from  type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																					");
																  while($data=mysql_fetch_array($query)){  
																 ?>
														<tr>
															<td><?php echo $data['nama_merk'] ?></td>
                                                            <td><?php echo $data['nama_type'] ?></td>
                                                            <td>
																<?php 
                                                                        if($data['status_type'] == 0)
                                                                            {
                                                                                echo '<font color=blue>Aktif</font>';
                                                                            }
                                                                        if($data['status_type'] == 1)
                                                                            {
                                                                                echo '<font color=red>Tidak Aktif</font>';
                                                                            }
                                                                ?>
                                                            </td>
                                                            <td>
                                                                <a href="?page=pages/edittype&id=<?php echo $data['id_type']; ?>">Edit</a>
                                                            </td>
														</tr>
																<?php $no++;}?>
													</tbody>
												</table>