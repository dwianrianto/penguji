
<script language="javascript">
function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>";
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
return false;
}
</script>

<input name="b_print" type="button" class="ipt"   onClick="printdiv('div_print');" value=" Print ">


<div id="div_print">
    	<center>

<img src="images/jayaraya.png" width="72" height="76" />
				<br/>

			DINAS PERHUBUNGAN DAN TRANSPORTASI
				<br/>
			PROVINSI DAERAH KHUSUS IBUKOTA JAKARTA
				<br/><br/>
			TENTANG
				<br/><br/>
			PENELITIAN DAN PENILAIAN FISIK
				<br/>
KENDARAAN BERMOTOR PRODUKSI KAROSERI	
				<br/><br/>
					<p align="left">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Dalam rangka menjamin kesesuaian fisik kendaraan bermotor hasil 
produksi karoseri dengan rancang bangun dan rekayasa kendaraan 
bermotor yang disahkan oleh Direktur Jenderal Perhubungan Darat 
perlu dilakukan pemeriksaan fisik secara langsung terhadap setiap 
unit produksi karoseri kendaraan bermotor, maka Kepala Bidang 
Bidang Pengendalian Operasional Dinas Perhubungan Provinsi DKI Jakarta dengan ini
					</p>
					
					MENUGASKAN  :
						<br/><br/>
						
				<table width="100%">
					<tr>
					  <td>Kepada</td>
					  <td>:</td>
					  <td>&nbsp;</td>
				  </tr>
					<tr>
						<td width="25%">&nbsp;</td>
						<td width="5%">&nbsp;</td>
						<td>
								<table width="100%">
											
											<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("SELECT
   `pegawai`.*,
   `detail_spt`.*,
   `pengajuan`.*
FROM
   `pegawai`
  INNER JOIN  `detail_spt` ON  `detail_spt`.`id_pegawai` =
     `pegawai`.`id_pegawai`
  INNER JOIN  `pengajuan` ON  `detail_spt`.`id_pengajuan`
    =  `pengajuan`.`id_pengajuan` where pengajuan.id_pengajuan='$id'");
																  while($data=mysql_fetch_array($query)){  
																?>
								
								
									<tr>
										<td width="5%"><?php echo $no; ?>.</td>
										<td width="47%"><u><?php echo $data['nama_pegawai']; ?></u></td>
										<td width="48%"> Selaku <?php echo $data['jabatan_pegawai']; ?></td>
									</tr>
									<tr>
										<td colspan="3">
                                        	NIP : <?php echo $data['nip']; ?>
                                            	<br/>
                                        </td>
									</tr>
									
	<?php $no++;}?>
								</table>
						</td>
					</tr>
					<tr>
					  <td>&nbsp;</td>
					  <td>&nbsp;</td>
					  <td>&nbsp;</td>
				  </tr>
					<tr>
					  <td>Untuk </td>
					  <td>: </td>
					  <td>&nbsp;</td>
				  </tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>
                        			<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
   `pengajuan`.*,
   `perusahaan`.*,
   `spt`.*,
   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`,
   `spt`.`id_pengajuan` AS `id_pengajuan1`
FROM
   `pengajuan`
  INNER JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
    =  `perusahaan`.`id_perusahaan`
  INNER JOIN  `spt` ON  `spt`.`id_pengajuan` =
     `pengajuan`.`id_pengajuan`
	where pengajuan.id_pengajuan='$id'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
									1.	Melaksanakan  Pemeriksaan  Fisik Kendaraan Bermotor setiap unit hasil
                                    	<br/>
                                    	Produksi Karoseri <?php echo $perusahaan['nama_perusahaan']; ?>
										
										<br/>
										sesuai surat permohonan nomor  : <?php echo $perusahaan['no_pengajuan']; ?>
                                        <br/>
										Tanggal : <?php echo $perusahaan['tgl_pengajuan']; ?>
										<br/>
									2.	Sebelum melaksanakan tugas agar terlebih dahulu melapor kepada
										<br/>
									3.	Selesai tugas agar membuat laporan pelaksanaan dimaksud.
										<br/>
									4.	urat perintah ini agar dapat dilaksanakan dengan sebaik – baiknya dandengan penuh rasa tanggung jawab.

						</td>
					</tr>
				</table>
						<table width="100%">
                        	<tr>
                            	<td width="57%">&nbsp;</td>
                                <td width="43%">
                                
                                		Dikeluarkan di Jakarta
                                        	<br/>
                                        Pada Tanggal <?php echo date('M-Y'); ?>
                                        	<br/>
                                        <h6>
                                        KEPALA BIDANG OPERASIONAL
                                        	<br/>
                                         DINAS PERHUBUNGAN DAN TRANSPORTASI
                                         	<br/>
                                          PROVINSI DKI JAKARTA
                                          
                                          		<br/><br/><br/>
                                          MARULITUA
                                          NIP : 197510191994121001
                                  </h6>
                                
                                </td>
                            </tr>
                        </table>
                        

		</center>
                        Tembusan  :
                        	<br/>
1. Kepala Dinas Perhubungan Dan Transportasi Provinsi DKI Jakarta;
	<br/>
2. Wakil Kepala Dinas Perhubungan Dan Transportasi Provinsi DKI Jakarta;
	<br/>
3. Sekretaris Dinas Perhubungan Dan Transportasi Provinsi DKI Jakarta.

</div>