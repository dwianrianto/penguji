<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$id_pegawai=$_POST['id_pegawai'];
$id_pengajuan=$_POST['id_pengajuan'];

$query=mysql_query("insert into detail_spt
(id_pegawai,id_pengajuan)
	 values 
('$id_pegawai','$id_pengajuan')") or die(mysql_error());


		}
?>





<!DOCTYPE html>
<html>
<head>


</head>
<body>

	<h4>
		Buat SPT
	</h4>
		<hr/>
		
		
										
<form method="POST" action="">
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
																		   `pengajuan`.*,
																		   `perusahaan`.*,
																		   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`
																		FROM
																		   `pengajuan`
																		  LEFT JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
																			=  `perusahaan`.`id_perusahaan` where id_pengajuan='$id'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Nama Perusahaan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_perusahaan']; ?></font>
																	</div>
																<br/><br/>
							<input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_pengajuan']; ?></font>
																	</div>
																<br/><br/>
																
																
			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Merk/Type</th>
                <th>Jenis/Konstruksi</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_pengajuan='$id'
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?> <?php echo $data['nama_konstruksi']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
																
																
																
																<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Petugas
																	</label>
						
		<link rel="stylesheet" href="chosens.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>
          
					<select name="id_pegawai" data-placeholder="Choose a Country..." class="chosen-select" style="width:350px;" tabindex="2" required="required">
												<option value=""></option>
														<?php
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from pegawai");
																  while($data=mysql_fetch_array($query)){  
																?>
												<option value="<?php echo $data['id_pegawai']; ?>"><?php echo $data['nama_pegawai']; ?></option>
															<?php } ?>
											  </select>
												<br/><br/>
		  
		  
  <script src="../assets/js/jquery.min.js" type="text/javascript"></script>
  <script src="chosens.js" type="text/javascript"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>				

										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

										</div>
</form>
											<br/><br/>
					
					
					
					<form action="pages/selesaispt.php" method="POST">
							<input type="hidden" name="id" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
							<input type="submit" name="selesaispt" value="Selesai" class="btn btn-sm btn-danger" />
					</form>

			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Nama Pegawai</th>
                <th>NIP</th>
				<th>Bagian</th>
				<th>Jabatan</th>
				<th>Action</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("SELECT
   `pegawai`.*,
   `detail_spt`.*,
   `pengajuan`.*
FROM
   `pegawai`
  INNER JOIN  `detail_spt` ON  `detail_spt`.`id_pegawai` =
     `pegawai`.`id_pegawai`
  INNER JOIN  `pengajuan` ON  `detail_spt`.`id_pengajuan`
    =  `pengajuan`.`id_pengajuan` where pengajuan.id_pengajuan='$id'");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_pegawai']; ?></td>
                <td><?php echo $data['nip']; ?></td>
				<td><?php echo $data['bagian_pegawai']; ?></td>
				<td><?php echo $data['jabatan_pegawai']; ?></td>
                <td>Delete</td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>