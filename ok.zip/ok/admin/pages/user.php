
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
	

<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<body>

			<h4>
            	Data Pegawai
            </h4>
            	<hr/>

	<?php if($_SESSION['level'] == 'admin'){ ?>
								<a href="?page=pages/tambahuser">
							<button class="btn btn-sm btn-info"><i class="ace-icon glyphicon glyphicon-plus"></i>Tambah</button>
								</a>
								<a href="?page=pages/edituser">
							<button class="btn btn-sm btn-warning"><i class="ace-icon fa fa-pencil-square-o"></i>Edit</button>
								</a>
								<br/><br/>
   <?php } ?>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th><b>NIP</b></th>
															<th><b>Nama Pegawai</b></th>
															<th><b>Bagian Pegawai</b></th>
                                                            <th><b>jabatan Pegawai</b></th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from pegawai");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nip'] ?></td>
															<td><?php echo $data['nama_pegawai'] ?></td>
															<td><?php echo $data['bagian_pegawai'] ?></td>
                                                            <td><?php echo $data['jabatan_pegawai'] ?></td>
                <td><?php if($_SESSION['level'] == 'admin'){ ?>
                Edit || Delete
                <?php } ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
	</body>