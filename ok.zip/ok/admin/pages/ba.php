<script language="javascript">
function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>";
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
return false;
}
</script>

<input name="b_print" type="button" class="ipt"   onClick="printdiv('div_print');" value=" Print ">


<div id="div_print">
    	<center>

<img src="images/jayaraya.png" width="72" height="76" />
		</center>

	


<p align="center"><strong>BERITA ACARA KUNJUNGAN LAPANGAN</strong><br>
  <strong><u>PENELITIAN DAN  PENILAIAN FISIK KENDARAAN BERMOTOR</u></strong><u> </u></p>
<p>Pada hari ini . . . . . . . . tanggal . . . . . . bulan .  . . . . . . . . . tahun . . . . , kami yang bertanda tangan di bawah ini :</p>
<ol start="1" type="1">
  <li>Utang.  . . . . . . . . . . . . .                           Ketua Tim</li>
  <li>Arie Fitriad .  . . . . . . . . .                           Anggota</li>
  <li>rahardian . . . . . . . . . . . .                           Anggota</li>
</ol>
<p>&nbsp;</p>
<p>Berdasarkan :<br>
  Surat Perintah Tugas Kepala bidang Pengendalian  Operasional Dinas Perhubungan dan Transportasi   Provinsi DKI Jakarta Nomor : . . . . . . /-1.811.111 tanggal . . . . . .  . . . . ., Tentang Penelitian dan Penilaian Fisik Kendaraan Bermotor.<br>
  Telah melaksanakan penelitian dan penilaian kesesuaian  antara fisik kendaraan bermotor dengan rancang bangun dan rekayasa kendaraan  bermotor yang telah ditetapkan Direktorat Jenderal Perhubungan Darat, berupa  rumah-rumah/ bak muatan/ modifikasi oleh :<br>
  Nama Perusahaan                                 :  CV. ANUGERAH KARYA MANDIRI. . . . . .<br>
  Surat Permohonan PT./CV                     :  987987 . . . . . . . . . Tanggal 26-07-2016 . . . . . . . . .  . .<br>
  Alamat                                                  : Jl. Pelopor IV No. 17 RT. 01/05 Tegal Alur Kalideres Jakarta. . . . . . . .  . .<br>
  Berdasarkan hasil penelitian dan penilaian fidik  kendaraan bermotor yang dilakukan, dengan kesimpulan sebagai berikut :</p>
<ol start="1" type="a">
  <li>Pengajuan penelitian dan penilaian sebanyak      : 5. . . . unit</li>
  <li>Terdapat kesesuaian fisik sebanyak                   : 5 . . . unit</li>
  <li>Tidak sesuai sebanyak                                      : . . . . . . unit</li>
  <li>Kendaraan belum ada                                        :       . . . . . . unit</li>
</ol>
<p>Demikian Berita Acara Kunjungan Lapangan ini dibuat,  sebagai dasar pembuatan Berita Acara Hasil Penelitian dan Penilaian Fisik  Kendaraan Bermotor.</p>
<p>&nbsp;</p>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="222" valign="top"><p align="center"><strong>PT. / CV</strong></p>
      <p align="center">&nbsp;</p>
      <p align="center">( . . . . . . . . . . . . . . . . . . . . . . . )</p></td>
    <td width="182" valign="top"><p>&nbsp;</p></td>
    <td width="263" valign="top"><ol>
      <li>Ketua        (Utang. . . . . . . . . . . . . .    )</li>
      <li>Anggota    (Arie Fitriad . . . . . . . . . . . . . )</li>
      <li>Anggota    (Rahardian . . . . . . . . . . . . . . )</li>
    </ol></td>
  </tr>
  <tr>
    <td width="667" colspan="3" valign="top"><p><strong>&nbsp;</strong></p>
      <p align="center"><strong>Mengetahui,</strong><br>
        <strong>Kepala Bidang    Pengendalian dan Operasional</strong><br>
        <strong>Dinas    Perhubungan dan Transportasi Provinsi DKI Jakarta</strong></p>
      <p align="center"><strong>&nbsp;</strong></p>
      <p align="center"><strong>MARULITUA</strong><br>
        <strong>NIP.    197510191994121001</strong></p></td>
  </tr>
</table>

</div>