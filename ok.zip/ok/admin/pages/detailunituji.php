<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
    	<h3>
        	Hasil Uji
        </h3>
<hr/>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="signupform" autocomplete="off">
		<input type="hidden" name="id_detailpengajuan" value="<?php echo $id=$_GET['id']; ?>" />
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_detailpengajuan='$id'
	 ");
																  $perusahaan=mysql_fetch_array($query2);
																?>
         <input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Jenis / Type</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_jenis']; ?>
                                                                         / <?php echo $perusahaan['nama_type']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Sk / Tgl</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_sk']; ?>
                                                                         / <?php echo $perusahaan['tgl_sk']; ?></font>
																	</div>
																<br/><br/>
																				<input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>No. Chasis</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_chasis']; ?></font>
																	</div>
																<br/><br/>
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>No. Engine</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_engine']; ?></font>
																	</div>
																<br/><br/>
                                                                	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Ket</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['ket_detailpengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Fisik</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['fisik']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Panjang</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['panjang']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Lebar</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['lebar']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Tinggi</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['tinggi']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>FOH</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['foh']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>A</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['a']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>ROH</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['roh']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>I</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['i']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>KET</b>
																	</label>
																	<div class="col-sm-9">
																	<font size="3"><?php echo $perusahaan['ket']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Photo</b>
																	</label>
																	<div class="col-sm-9">
                                                                    
<img src="../penguji/images/imgproduct/<?php echo $perusahaan['foto']; ?>" width="300px" />
																	</div>
																<br/><br/>
</form>
</body>
</html>
