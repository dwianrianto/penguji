
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
	
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>
				<h4>
                	HIstory Unit Kendaraan
                </h4>
                	<hr/>
			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
            	<th>No.</th>
                <th>JENIS/TYPE</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
                <th>Panjang</th>
                <th>Tinggi</th>
                <th>Lebar</th>
                <th>FOH</th>
                <th>A</th>
                <th>ROH</th>
                <th>I</th>
                <th>Ket</th>
				<th>Hasil</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("SELECT
																				   `jenis`.*,
																				   `type`.*,
																				   `sk`.*,
																				   `detail_pengajuan`.*,
																				   `type`.`id_jenis` AS `id_jenis1`,
																				   `pengajuan`.*,
																				   `detail_pengajuan`.`id_pengajuan` AS `id_pengajuan1`
																				FROM
																				   `jenis`
																				  INNER JOIN  `type` ON  `type`.`id_jenis` =
																					 `jenis`.`id_jenis`
																				  INNER JOIN  `sk` ON  `sk`.`id_type` =
																					 `type`.`id_type`
																				  INNER JOIN  `detail_pengajuan`
																					ON  `detail_pengajuan`.`id_sk` =  `sk`.`id_sk`
																				  INNER JOIN  `pengajuan`
																					ON  `detail_pengajuan`.`id_pengajuan` =
																					 `pengajuan`.`id_pengajuan` where detail_pengajuan.no_chasis='$id'");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
            	<td><?php echo $no; ?></td>
				<td><?php echo $data['nama_jenis']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
                <td><?php echo $data['panjang']; ?></td>
                <td><?php echo $data['tinggi']; ?></td>
                <td><?php echo $data['lebar']; ?></td>
                <td><?php echo $data['foh']; ?></td>
                <td><?php echo $data['a']; ?></td>
                <td><?php echo $data['roh']; ?></td>
                <td><?php echo $data['i']; ?></td>
                <td><?php echo $data['ket']; ?></td>
                <td>
                	<?php
						if($data['status_detailpengajuan'] == '1')
							{
								echo 'di Tolak';
							}
						if($data['status_detailpengajuan'] == '0')
							{
								echo 'Belum di Uji';
							}
					?>
                </td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>