<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>
        <link rel="stylesheet" type="text/css" href="button/style4.css" />
        		<h4>
        	Master Data
            	</h4>
            	<hr/>
                		<?php if($_SESSION['level'] == 'admin'){ ?>
								<a href="?page=pages/merk">
							<button class="a_demo_four"><i class="ace-icon fa fa-pencil-square-o"></i> Merk</button>
								</a>
                                <a href="?page=pages/tambahtype">
							<button class="a_demo_four"><i class="ace-icon fa fa-pencil-square-o"></i> Type</button>
								</a>
                                <a href="?page=pages/tambahjenis">
							<button class="a_demo_four"><i class="ace-icon fa fa-pencil-square-o"></i> Jenis</button>
								</a>
                                <a href="?page=pages/sk">
							<button class="a_demo_four"><i class="ace-icon fa fa-pencil-square-o"></i> SK</button>
								</a>
								<br/><br/>
                        <?php } ?>
                                
                                <table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Merk</th>
                <th>Type</th>
                <th>Jenis</th>
                <th>Konstruksi</th>
				<th>No. SK</th>
                <th>Tgl SK</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select
																  						sk.*,
																  						jenis.*,
																  						type.*,
																						merk.*
																						from sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?></td>
                <td><?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?></td>
                <td><?php echo $data['nama_konstruksi']; ?></td>
				<td><?php echo $data['no_sk']; ?></td>
                <td><?php echo $data['tgl_sk']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>