


<!DOCTYPE html>
<html>
<head>



</head>
<body>
			<h4>
            	Status Pengajuan : <input type="submit" name="acc" value="Sudah ACC Kasie" class="btn btn-sm btn-primary">
            </h4>
            	<hr/>
                                    
	<h4>
		Detail Pengajuan
	</h4>
		<hr/>
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
																		   `pengajuan`.*,
																		   `perusahaan`.*,
																		   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`
																		FROM
																		   `pengajuan`
																		  LEFT JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
																			=  `perusahaan`.`id_perusahaan` where id_pengajuan='$id'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Nama Perusahaan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_perusahaan']; ?></font>
																	</div>
																<br/><br/>
																				<input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_pengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Perihal
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['perihal_pengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Tanggal
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['tgl_pengajuan']; ?></font>
																	</div>
																<br/><br/>
					
					<h4>
                    	Detail Kendaraan
                    </h4>
                    	<hr/>

			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>JENIS/TYPE</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
				<th>ACTION</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("SELECT
																				   `jenis`.*,
																				   `type`.*,
																				   `sk`.*,
																				   `detail_pengajuan`.*,
																				   `type`.`id_jenis` AS `id_jenis1`,
																				   `pengajuan`.*,
																				   `detail_pengajuan`.`id_pengajuan` AS `id_pengajuan1`
																				FROM
																				   `jenis`
																				  INNER JOIN  `type` ON  `type`.`id_jenis` =
																					 `jenis`.`id_jenis`
																				  INNER JOIN  `sk` ON  `sk`.`id_type` =
																					 `type`.`id_type`
																				  INNER JOIN  `detail_pengajuan`
																					ON  `detail_pengajuan`.`id_sk` =  `sk`.`id_sk`
																				  INNER JOIN  `pengajuan`
																					ON  `detail_pengajuan`.`id_pengajuan` =
																					 `pengajuan`.`id_pengajuan` where detail_pengajuan.id_pengajuan='$id'");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_jenis']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
                <td>Delete</td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>