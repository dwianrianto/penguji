<?php

if($_POST['acc']){
include "../config/koneksi.php";

$id_pengajuan=$_POST['id_pengajuan'];
$date=date('d-m-Y');

$query3=mysql_query("update pengajuan set kasie_a='1',tglkasie_a='$date' where id_pengajuan='$id_pengajuan'") or die(mysql_error());

?>
	<script>document.location='index.php?page=pages/kasie/alertkasie';</script>
<?php

		}
?>





<!DOCTYPE html>
<html>
<head>

</head>
<body>

		
		
					<form action="" method="POST">
					
								<input type="hidden" name="id_pengajuan" value="<?php echo $id=$_GET['id']; ?>" />
							<input type="submit" name="acc" value="Acc Pengajuan" class="btn btn-sm btn-primary">
                                
                    
                    </form>
                                	<hr/>
                                    
	<h4>
		Detail Pengajuan
	</h4>
		<hr/>
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
																		   `pengajuan`.*,
																		   `perusahaan`.*,
																		   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`
																		FROM
																		   `pengajuan`
																		  LEFT JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
																			=  `perusahaan`.`id_perusahaan` where id_pengajuan='$id'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Nama Perusahaan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_perusahaan']; ?></font>
																	</div>
																<br/><br/>
																				<input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_pengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Perihal
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['perihal_pengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Tanggal
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['tgl_pengajuan']; ?></font>
																	</div>
																<br/><br/>
					
					<h4>
                    	Detail Kendaraan
                    </h4>
                    	<hr/>

			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Merk/Type</th>
                <th>Jenis/Konstruksi</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_pengajuan='$id'
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?> / <?php echo $data['nama_konstruksi']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>