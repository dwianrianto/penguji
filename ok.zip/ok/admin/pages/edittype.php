<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$id_type=$_POST['id_type'];
$id_merk=$_POST['id_merk'];
$nama_type=$_POST['nama_type'];
$status_type=$_POST['status_type'];

$query=mysql_query("update type set nama_type='$nama_type', id_merk='$id_merk', status_type='$status_type' where id_type='$id_type'") or die(mysql_error());


if ($query){

	?>
		<div class="alert bg-info" role="alert">
                        	<center>
					<span class="glyphicon glyphicon-exclamation-sign"></span> Edit Data Type Berhasil di Simpan ...
                    		</center>
				</div>
<?php 
	}
	else{
		echo"gagal";
		}
	}
?>
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<body>
		<a href="?page=pages/tambahtype">
							<button class="btn btn-sm btn-danger"> Back to Type </button>
								</a>
					<h4>
                    	Edit Data Type
                    </h4>
                    	<hr/>
                        
                        <form class="form-horizontal" role="form" action="" method="post">
                        	<?php
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						type.*,
																						merk.*
																						from  type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																						where type.id_type='$id'
																						");
																  $data=mysql_fetch_array($query); 
																?>
									<div class="form-group">
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Merk </label>

										<div class="col-sm-9">
  <link rel="stylesheet" href="chosens.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>
                                        <select name="id_merk" data-placeholder="Choose a Country..." class="chosen-select" style="width:350px;" tabindex="2" required="required">
                                        <option value="<?php echo $data['id_merk']; ?>"><?php echo $data['nama_merk']; ?></option>
																<?php
																  include"../config/koneksi.php";
																  $query2=mysql_query("select * from merk");
																  while($data2=mysql_fetch_array($query2)){  
																?>
										<option value="<?php echo $data2['id_merk']; ?>"><?php echo $data2['nama_merk']; ?></option>
																<?php } ?>
											</select>
                                            
   
  <script src="../assets/js/jquery.min.js" type="text/javascript"></script>
  <script src="chosens.js" type="text/javascript"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>				
										</div>
										<br/><br/><br/>
                                    
                                    <div class="form-group">
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nama Type </label>

										<div class="col-sm-9">
                                        <input type="hidden" name="id_type" value="<?php echo $id; ?>" />
                                        
											<input type="text" name="nama_type" value="<?php echo $data['nama_type']; ?>" id="form-field-1" placeholder="Merk" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
									</div>
                                    
                                    <div class="form-group">
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Status Merk </label>

										<div class="col-sm-9">
											<?php
												if($data['status_type'] == 0)
													{
														echo	'<input name=status_type type=radio value=0 checked> Aktif
																<br/>
															  <input name=status_type type=radio value=1> Tidak Aktif
															';
													}
												if($data['status_type'] == 1)
													{
														echo	'<input name=status_type type=radio value=0> Aktif
																<br/>
															  <input name=status_type type=radio value=1 checked> Tidak Aktif
															';
													}
											?>
										</div>
										<br/><br/><br/>
										
									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
	</body>