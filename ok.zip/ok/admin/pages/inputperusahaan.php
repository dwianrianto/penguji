<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>


<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$nama_perusahaan=$_POST['nama_perusahaan'];
$jenis_perusahaan=$_POST['jenis_perusahaan'];
$alamat_perusahaan=$_POST['alamat_perusahaan'];
$penanggung_jawab=$_POST['penanggung_jawab'];
$telp_perusahaan=$_POST['telp_perusahaan'];
$telp_perusahaan2=$_POST['telp_perusahaan2'];
$telp_perusahaan3=$_POST['telp_perusahaan3'];
$fax_perusahaan=$_POST['fax_perusahaan'];

$query=mysql_query("insert into perusahaan
(nama_perusahaan,jenis_perusahaan,alamat_perusahaan,penanggung_jawab,telp_perusahaan,telp_perusahaan2,telp_perusahaan3,fax_perusahaan)
	 values 
('$nama_perusahaan','$jenis_perusahaan','$alamat_perusahaan','$penanggung_jawab','$telp_perusahaan','$telp_perusahaan2','$telp_perusahaan3','$fax_perusahaan')") or die(mysql_error());


if ($query){

	?>
		<div class="alert bg-info" role="alert">
                        	<center>
					<span class="glyphicon glyphicon-exclamation-sign"></span> Data Perusahaan Berhasil di Simpan  ...
						<h6 class="pink">
									<i class="ace-icon fa fa-hand-o-right icon-animated-hand-pointer blue"></i>
									<a href="#modal-table" role="button" data-toggle="modal"> Lihat Data Perusahaan </a>
								</h6>
                    		</center>
				</div>
<?php 
	}
	else{
		echo"gagal";
		}
		}
?>


<h3>
	Data Perusahaan Baru
</h3>


<form class="form-horizontal" role="form" action="" method="post">
									<div class="form-group">
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nama Perusahaan </label>

										<div class="col-sm-9">
											<input type="text" name="nama_perusahaan" id="form-field-1" placeholder="Username" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Jenis Perusahaan </label>

										<div class="col-sm-9">
											<input type="text" name="jenis_perusahaan" value="KAROSERI" id="form-field-1" placeholder="Username" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Alamat </label>
										<div class="col-sm-9">
															<textarea name="alamat_perusahaan" class="col-xs-10 col-sm-5" id="form-field-1" placeholder="Default Text"></textarea>
										</div>
										<br/><br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Penanggung Jawab </label>

										<div class="col-sm-9">
											<input type="text" name="penanggung_jawab" id="form-field-1" placeholder="Penanggung Jawab" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor Telepon </label>
										<div class="col-sm-9">
															<div class="input-group">
																<span class="input-group-addon">
																	<i class="ace-icon fa fa-phone"></i>
																</span>

																<input name="telp_perusahaan" class="col-xs-10 col-sm-5" type="text" id="form-field-mask-2" />
															</div>
										</div>
                                        <br/><br/><br/>
                                        
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor Telepon 2 </label>
										<div class="col-sm-9">
															<div class="input-group">
																<span class="input-group-addon">
																	<i class="ace-icon fa fa-phone"></i>
																</span>

																<input name="telp_perusahaan2" class="col-xs-10 col-sm-5" type="text" id="form-field-mask-2" />
															</div>
										</div>
                                        <br/><br/><br/>
                                        
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor Telepon 3 </label>
										<div class="col-sm-9">
															<div class="input-group">
																<span class="input-group-addon">
																	<i class="ace-icon fa fa-phone"></i>
																</span>

																<input name="telp_perusahaan3" class="col-xs-10 col-sm-5" type="text" id="form-field-mask-2" />
															</div>
										</div>
                                        <br/><br/><br/>
                                    
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor Fax </label>
										<div class="col-sm-9">
															<div class="input-group">
																<span class="input-group-addon">
																	<i class="ace-icon fa fa-phone"></i>
																</span>

																<input name="fax_perusahaan" class="col-xs-10 col-sm-5" type="text" id="form-field-mask-2" />
															</div>
										</div>
                                        <br/>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
</form>									</div>

									<div class="hr hr-24"></div>
									
									<div id="modal-table" class="modal fade" tabindex="-1">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header no-padding">
												<div class="table-header">
													<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
														<span class="white">&times;</span>
													</button>
													Results for "Latest Registered Domains
												</div>
											</div>

											<div class="modal-body no-padding">
												<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
													<thead>
														<tr>
															<th><b>Nama Perusahaan</b></th>
															<th><b>Jenis</b></th>
															<th><b>Alamat</b></th>
                                                            <th><b>Penanggung Jawab</b></th>
															<th>Telp</th>
                                                            <th>Telp2</th>
                                                            <th>Telp3</th>
                                                            <th>Fax</th>
														</tr>
													</thead>

													<tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from perusahaan");
																  while($data=mysql_fetch_array($query)){  
																 ?>
														<tr>
															<td><?php echo $data['nama_perusahaan'] ?></td>
															<td><?php echo $data['jenis_perusahaan'] ?></td>
															<td><?php echo $data['alamat_perusahaan'] ?></td>
                                                            <td><?php echo $data['penanggung_jawab'] ?></td>
															<td><?php echo $data['telp_perusahaan'] ?></td>
                                                            <td><?php echo $data['telp_perusahaan2'] ?></td>
                                                            <td><?php echo $data['telp_perusahaan3'] ?></td>
                                                            <td><?php echo $data['fax_perusahaan'] ?></td>
														</tr>
																<?php $no++;}?>
													</tbody>
												</table>
											</div>

											<div class="modal-footer no-margin-top">
												<button class="btn btn-sm btn-danger pull-left" data-dismiss="modal">
													<i class="ace-icon fa fa-times"></i>
													Close
												</button>

												<ul class="pagination pull-right no-margin">
													<li class="prev disabled">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-left"></i>
														</a>
													</li>

													<li class="active">
														<a href="#">1</a>
													</li>

													<li>
														<a href="#">2</a>
													</li>

													<li>
														<a href="#">3</a>
													</li>

													<li class="next">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-right"></i>
														</a>
													</li>
												</ul>
											</div>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->