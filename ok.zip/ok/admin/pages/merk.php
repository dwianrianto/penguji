<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$nama_merk=$_POST['nama_merk'];

$query=mysql_query("insert into merk
(nama_merk)
	 values 
('$nama_merk')") or die(mysql_error());


if ($query){

	?>
		<div class="alert bg-info" role="alert">
                        	<center>
					<span class="glyphicon glyphicon-exclamation-sign"></span> Jenis Baru Berhasil di Simpan  ...
                    		</center>
				</div>
<?php 
	}
	else{
		echo"gagal";
		}
	}
?>
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<body>
		<a href="?page=pages/master">
							<button class="btn btn-sm btn-danger"> Back to Master </button>
								</a>
					<h4>
                    	Data Merk
                    </h4>
                    	<hr/>
                        
                        <form class="form-horizontal" role="form" action="" method="post">
									<div class="form-group">
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nama Merk </label>

										<div class="col-sm-9">
											<input type="text" name="nama_merk" id="form-field-1" placeholder="Merk" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Merk</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from merk");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?></td>
                <td>
					<?php 
							if($data['status_merk'] == 0)
								{
									echo '<font color=blue>Aktif</font>';
								}
							if($data['status_merk'] == 1)
								{
									echo '<font color=red>Tidak Aktif</font>';
								}
					?>
                </td>
                <td>
                	<a href="?page=pages/editmerk&id=<?php echo $data['id_merk']; ?>">Edit</a>
                </td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
	</body>