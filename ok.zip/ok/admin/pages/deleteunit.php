<?php
	include"../../config/koneksi.php";
	$id=$_GET['id'];
	$chasis=$_GET['chasis'];
	$query=mysql_query("delete from detail_pengajuan where id_detailpengajuan='$id'");
	
	$query2=mysql_query("select * from unit where chasis='$chasis'");
	$data=mysql_fetch_array($query2);
	$kurang=$data['jumlah_ujiunit']-1;
	
	
if ($kurang == 0){
		$query3=mysql_query("delete from unit where chasis='$chasis'");
	}
if ($kurang > 0){
		$query4=mysql_query("update unit set jumlah_ujiunit='$kurang' where chasis='$chasis'");
	}
?>

<script>javascript:history.go(-1)</script>