
<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<link rel="stylesheet" href="css/BeatPicker.min.css"/>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/BeatPicker.min.js"></script>
    
<div class="panel panel-default">
					<div class="panel-heading">Rekap Laporan</div>
					<div class="panel-body">
						<div class="col-md-6">
				<form role="form" action="pages/viewrekap.php" method="post" target="_new">
                
								<div class="form-group">
									<label>Dari Taggal</label>
									<input name="tgl1" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" autocomplete="off" />
                                    <label>Sampai Tanggal</label>
									<input name="tgl2" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" autocomplete="off" />
								</div>
                                
							<div class="col-md-7">
							  <input type="submit" class="btn btn-primary" name="show" value="Tampilkan">
							</div>
						</form>
					</div>
				</div>
                
                