<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$no_chasis=$_POST['no_chasis'];
$no_engine=$_POST['no_engine'];
$ket_detailpengajuan=$_POST['ket'];
$id_pengajuan=$_POST['id_pengajuan'];
$id_sk=$_POST['id_sk'];

$query=mysql_query("insert into detail_pengajuan
(no_chasis,no_engine,ket_detailpengajuan,id_pengajuan,id_sk)
	 values 
('$no_chasis','$no_engine','$ket_detailpengajuan','$id_pengajuan','$id_sk')") or die(mysql_error());

$querycek=mysql_query("select chasis from unit where chasis='$no_chasis'");
$cek=mysql_num_rows($querycek);

	if($cek == 0)
		{

$query2=mysql_query("insert into unit
(chasis,engine,ket,jumlah_ujiunit)
	 values 
('$no_chasis','$no_engine','$ket_detailpengajuan','1')") or die(mysql_error());

		}
	else{
	
$querycek2=mysql_query("select jumlah_ujiunit from unit");
$cek2=mysql_fetch_array($querycek2);
$hasil=$cek2['jumlah_ujiunit']+1;


$query3=mysql_query("update unit set jumlah_ujiunit='$hasil'") or die(mysql_error());

	}
		}
?>





<!DOCTYPE html>
<html>
<head>

<script type="text/javascript" src="register/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$("#namad").keyup(function() {
var namad = $('#namad').val();
if(namad=="")
{
$("#disp").html("");
}
else
{
$.ajax({
type: "POST",
url: "register/validate.php",
data: "namad="+ namad ,
success: function(html){
$("#disp").html(html);
}
});
return false;
}
});
});
</script>



</head>
<body>

	<h4>
		Input Unit Kendaraan
	</h4>
		<hr/>
		
		
										
<form method="POST" action="">
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
																		   `pengajuan`.*,
																		   `perusahaan`.*,
																		   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`
																		FROM
																		   `pengajuan`
																		  LEFT JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
																			=  `perusahaan`.`id_perusahaan` where id_pengajuan='$id'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Nama Perusahaan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_perusahaan']; ?></font>
																	</div>
																<br/><br/>
																				<input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_pengajuan']; ?></font>
																	</div>
																<br/><br/>
																<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Unit / SK
																	</label>
						<div class="col-sm-9">
		<link rel="stylesheet" href="chosens.css">
  <style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
  </style>
          
					<select name="id_sk" data-placeholder="Choose a Country..." class="chosen-select" style="width:350px;" tabindex="2" required="required">
												<option value=""></option>
														<?php
																  include"../config/koneksi.php";
																  $query=mysql_query("select
																  						sk.*,
																  						jenis.*,
																  						type.*,
																						merk.*
																						from sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																						");
																  while($data=mysql_fetch_array($query)){  
																?>
												<option value="<?php echo $data['id_sk']; ?>">
												<?php echo $data['nama_merk']; ?> 
												<?php echo $data['nama_type']; ?>
                                                 <?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?>
                                                 </option>
															<?php } ?>
											  </select>
												<br/><br/>
		  
		  
  <script src="../assets/js/jquery.min.js" type="text/javascript"></script>
  <script src="chosens.js" type="text/javascript"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>				
											  
</div>
											
										<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1"> Chasis </label>

										<div class="col-sm-9">
												<input name="no_chasis" id="namad" class="col-xs-10 col-sm-5" type="text" id="namad" autocomplete="off" required />
										</div>
		<br/><br/>
										<label name="perihal" class="col-sm-3 control-label no-padding-right" for="form-field-1"> Engine </label>

										<div class="col-sm-9">
											<input type="text" name="no_engine" id="form-field-1" placeholder="Perihal" class="col-xs-10 col-sm-5" required autocomplete="off" />
										</div>
											<br/><br/>
											
										<label name="perihal" class="col-sm-3 control-label no-padding-right" for="form-field-1"> Ket </label>

										<div class="col-sm-9">
											<input type="text" name="ket" id="form-field-1" placeholder="Perihal" class="col-xs-10 col-sm-5" required />
										</div>
											<br/><br/>

										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
</form>
			<br/><br/><br/>
					
					<div class="col-lg-offset-1 col-lg-9">
													<div id="disp">ok</div>
										</div>
											<br/><br/>
					
					
					
					
								<a href="?page=pages/selesaiunit&id=<?php echo $id=$_GET['id']; ?>">
							<button class="btn btn-sm btn-danger"><i class="ace-icon glyphicon glyphicon-pencil"></i>Selesai & Simpan</button>
								</a>

<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Merk/Type</th>
                <th>Jenis/Konstruksi</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
				<th>ACTION</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_pengajuan='$id'
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
                <td><?php echo $no; ?>. <?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?> / <?php echo $data['nama_konstruksi']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
                <td><a href="pages/deleteunit.php?id=<?php echo $data['id_detailpengajuan']; ?>&amp;chasis=<?php echo $data['no_chasis']; ?>" onClick="return confirm('Apakah Anda Ingin Menghapus Unit Ini ?');">Cansel</a></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>