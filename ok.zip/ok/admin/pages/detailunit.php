
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
	
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>
<?php
					include"../config/koneksi.php";
					$id=$_GET['id'];
					$queryl=mysql_query("select * from detail_pengajuan where id_pengajuan='$id' AND hasil_cek='lulus'");
					$datal=mysql_num_rows($queryl);
						?>
                       	<?php
					include"../config/koneksi.php";
					$id=$_GET['id'];
					$querytl=mysql_query("select * from detail_pengajuan where id_pengajuan='$id' AND hasil_cek='tidak_lulus'");
					$datatl=mysql_num_rows($querytl);
						?>
                        <label name="perusahaan" class="col-sm-1 control-label no-padding-right" for="form-field-1">
																		<b>Lulus</b>
																	</label>
																	<div class="col-sm-1">
																		<font size="3"><?php echo $datal; ?></font>
																	</div>
																<br/><br/>
                                            
                       <label name="perusahaan" class="col-sm-1 control-label no-padding-right" for="form-field-1">
																		<b>Tidak Lulus</b>
																	</label>
																	<div class="col-sm-1">
																		<font size="3"><?php echo $datatl; ?></font>
																	</div>
																<br/><br/>
                                </h4>
                                	</center>
				<h4>
                	Detail Kendaraan
                </h4>
                	<hr/>
			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
            	<th width="5%">No.</th>
               	<th>Merk/Type</th>
                <th>Jenis/Konstruksi</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
                <th>Panjang</th>
                <th>Tinggi</th>
                <th>Lebar</th>
                <th>FOH</th>
                <th>A</th>
                <th>ROH</th>
                <th>I</th>
                <th>Ket</th>
				<th>ACTION</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_pengajuan='$id'");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
            	<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?> / <?php echo $data['nama_konstruksi']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
                <td><?php echo $data['panjang']; ?></td>
                <td><?php echo $data['tinggi']; ?></td>
                <td><?php echo $data['lebar']; ?></td>
                <td><?php echo $data['foh']; ?></td>
                <td><?php echo $data['a']; ?></td>
                <td><?php echo $data['roh']; ?></td>
                <td><?php echo $data['i']; ?></td>
                <td><?php echo $data['ket']; ?></td>
                <td>
                		<a href="?page=pages/detailunituji&id=<?php echo $data['id_detailpengajuan']; ?>">
                	View
                    	</a>
                </td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>