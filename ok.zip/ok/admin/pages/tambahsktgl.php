<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$id_type=$_POST['id_type'];
$no_sk=$_POST['no_sk'];
$tgl_sk=$_POST['tgl_sk'];

$query=mysql_query("insert into sk
(no_sk,tgl_sk,id_type)
	 values 
('$no_sk','$tgl_sk','$id_type')") or die(mysql_error());


if ($query){

	?>
		<div class="alert bg-info" role="alert">
                        	<center>
					<span class="glyphicon glyphicon-exclamation-sign"></span> SK Baru Berhasil di Simpan  ...
						<h6 class="pink">
									<i class="ace-icon fa fa-hand-o-right icon-animated-hand-pointer blue"></i>
									<a href="#modal-table" role="button" data-toggle="modal"> Lihat Data Perusahaan </a>
								</h6>
                    		</center>
				</div>
<?php 
	}
	else{
		echo"gagal";
		}
		}
?>


<h3>
	Tambah SK Baru
</h3>


<form class="form-horizontal" role="form" action="" method="post">
									<div class="form-group">
									
									
										<label class="col-sm-3 control-label no-padding-right"> Jenis / Type </label>

										<div class="col-sm-9">
											<select name="id_type" required="required">
															<option value="">Pilih Jenis</option>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("SELECT
																		  `jenis`.*,
																		  `type`.*
																		FROM
																		  `jenis`
																		  LEFT JOIN `type` ON `jenis`.`id_jenis` =
																			`type`.`id_jenis`");
																  while($data=mysql_fetch_array($query)){  
																?>
										<option value="<?php echo $data['id_type']; ?>"><?php echo $data['nama_jenis']; ?>/<?php echo $data['nama_type']; ?></option>
																<?php $no++;}?>
											</select>
										</div>
										<br/><br/><br/>
									
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Nomor SK </label>

										<div class="col-sm-9">
											<input type="text" name="no_sk" id="form-field-1" placeholder="No. SK" class="col-xs-10 col-sm-5" />
										</div>
										<br/><br/><br/>
										
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Tanggal SK </label>

										<div class="col-sm-9">

														<div class="row">
															<div class="col-xs-10 col-sm-5">
																<div class="input-group">
																	<input name="tgl_sk" class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
																	<span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>
																</div>
															</div>
														</div>
										</div>
											<br/><br/>
										
										
										
										
										
										
									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info" />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>

									<div class="hr hr-24"></div>
									
									<div id="modal-table" class="modal fade" tabindex="-1">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header no-padding">
												<div class="table-header">
													<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
														<span class="white">&times;</span>
													</button>
													Results for "Latest Registered Domains
												</div>
											</div>

											<div class="modal-body no-padding">
												<table class="table table-striped table-bordered table-hover no-margin-bottom no-border-top">
													<thead>
														<tr>
															<th><b>Nama Jenis</b></th>
														</tr>
													</thead>

													<tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from jenis");
																  while($data=mysql_fetch_array($query)){  
																 ?>
														<tr>
															<td><?php echo $data['nama_jenis'] ?></td>
														</tr>
																<?php $no++;}?>
													</tbody>
												</table>
											</div>

											<div class="modal-footer no-margin-top">
												<button class="btn btn-sm btn-danger pull-left" data-dismiss="modal">
													<i class="ace-icon fa fa-times"></i>
													Close
												</button>

												<ul class="pagination pull-right no-margin">
													<li class="prev disabled">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-left"></i>
														</a>
													</li>

													<li class="active">
														<a href="#">1</a>
													</li>

													<li>
														<a href="#">2</a>
													</li>

													<li>
														<a href="#">3</a>
													</li>

													<li class="next">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-right"></i>
														</a>
													</li>
												</ul>
											</div>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->