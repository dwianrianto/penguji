<?php

if($_POST['acc']){
include "../config/koneksi.php";

$id_pengajuan=$_POST['id_pengajuan'];
$date=date('d-m-Y');

$query3=mysql_query("update pengajuan set kabid_a='1',tglkabid_a='$date' where id_pengajuan='$id_pengajuan'") or die(mysql_error());

?>
	<script>document.location='index.php?page=pages/kabid/alertkabid';</script>
<?php

		}
?>





<!DOCTYPE html>
<html>
<head>

<script type="text/javascript" src="register/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$("#namad").keyup(function() {
var namad = $('#namad').val();
if(namad=="")
{
$("#disp").html("");
}
else
{
$.ajax({
type: "POST",
url: "register/validate.php",
data: "namad="+ namad ,
success: function(html){
$("#disp").html(html);
}
});
return false;
}
});
});
</script>



</head>
<body>

		
		
					<form action="" method="POST">
					
								<input type="hidden" name="id_pengajuan" value="<?php echo $id=$_GET['id']; ?>" />
							<input type="submit" name="acc" value="Acc Pengajuan" class="btn btn-sm btn-primary">
                    
                    </form>
                                	<hr/>
                                    
	<h4>
		Detail Pengajuan
	</h4>
		<hr/>
		
		
										
<form method="POST" action="">
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
   `pengajuan`.*,
   `perusahaan`.*,
   `spt`.*,
   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`,
   `spt`.`id_pengajuan` AS `id_pengajuan1`
FROM
   `pengajuan`
  INNER JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
    =  `perusahaan`.`id_perusahaan`
  INNER JOIN  `spt` ON  `spt`.`id_pengajuan` =
     `pengajuan`.`id_pengajuan`
	where pengajuan.id_pengajuan='$id'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Nama Perusahaan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_perusahaan']; ?></font>
																	</div>
																<br/><br/>
																
																
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_pengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Tanggal Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['tgl_pengajuan']; ?></font>
																	</div>
																<br/><br/>
																
																<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. SPT
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_spt']; ?></font>
																	</div>
																<br/><br/>
									
						<h4>
							Data Detail Kendaraan
						</h4>
							<hr/>
																
			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Merk/Type</th>
                <th>Jenis/Konstruksi</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_pengajuan='$id'
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?> / <?php echo $data['nama_konstruksi']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
												
						<h4>
							Data Detail Petugas Penguji
						</h4>
							<hr/>						
												
			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Nama Pegawai</th>
                <th>NIP</th>
				<th>Bagian</th>
				<th>Jabatan</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("SELECT
   `pegawai`.*,
   `detail_spt`.*,
   `pengajuan`.*
FROM
   `pegawai`
  INNER JOIN  `detail_spt` ON  `detail_spt`.`id_pegawai` =
     `pegawai`.`id_pegawai`
  INNER JOIN  `pengajuan` ON  `detail_spt`.`id_pengajuan`
    =  `pengajuan`.`id_pengajuan` where pengajuan.id_pengajuan='$id'");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_pegawai']; ?></td>
                <td><?php echo $data['nip']; ?></td>
				<td><?php echo $data['bagian_pegawai']; ?></td>
				<td><?php echo $data['jabatan_pegawai']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>