<?php

if($_POST['acc']){
include "../config/koneksi.php";

$id_pengajuan=$_POST['id_pengajuan'];
$date=date('d-m-Y');

$query3=mysql_query("update pengajuan set disposisi='1' where id_pengajuan='$id_pengajuan'") or die(mysql_error());

?>
	<script>document.location='index.php?page=pages/kabid/alertkabid';</script>
<?php

		}
?>





<!DOCTYPE html>
<html>
<head>

	
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
	
<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>


</head>
<body>

		
		
					<form action="" method="POST">
					
								<input type="hidden" name="id_pengajuan" value="<?php echo $id=$_GET['id']; ?>" />
							<input type="submit" name="acc" value="Tindak lanjut" class="btn btn-sm btn-primary">
                    
                    </form>
                                	<hr/>
                                    
	<h4>
		Detail Pengajuan
	</h4>
		<hr/>
		
		
										
<form method="POST" action="">
						
																<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("SELECT
   `pengajuan`.*,
   `perusahaan`.*,
   `pengajuan`.`id_perusahaan` AS `id_perusahaan1`
FROM
   `pengajuan`
  LEFT JOIN  `perusahaan` ON  `pengajuan`.`id_perusahaan`
    =  `perusahaan`.`id_perusahaan`
	where pengajuan.id_pengajuan='$id' AND pengajuan.disposisi='0'");
																  $perusahaan=mysql_fetch_array($query2);
																?>
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Nama Perusahaan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_perusahaan']; ?></font>
																	</div>
																<br/><br/>
																
																
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_pengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		Tanggal Pengajuan
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['tgl_pengajuan']; ?></font>
																	</div>
																<br/><br/>
																
																<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		No. SPT
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_spt']; ?></font>
																	</div>
																<br/><br/>
									
						<h4>
							Data Detail Kendaraan
						</h4>
							<hr/>
																
			<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Merk/Type</th>
                <th>Jenis/Konstruksi</th>
                <th>SK/TGL</th>
				<th>CHASIS</th>
				<th>ENGINE</th>
                <th>KET</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $id=$_GET['id'];
																  $query=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_pengajuan='$id'
																  ");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_merk']; ?> <?php echo $data['nama_type']; ?></td>
                <td><?php echo $data['nama_jenis']; ?> / <?php echo $data['nama_konstruksi']; ?></td>
                <td><?php echo $data['no_sk']; ?>/<?php echo $data['tgl_sk']; ?></td>
				<td><?php echo $data['no_chasis']; ?></td>
				<td><?php echo $data['no_engine']; ?></td>
				<td><?php echo $data['ket_detailpengajuan']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
</body>
</html>