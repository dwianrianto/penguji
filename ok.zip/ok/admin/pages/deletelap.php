<?php
	include"../config/koneksi.php";
	$id=$_GET['id'];
	
			$query=mysql_query("delete from monitoring where id_monitoring='$id'");
		?>
    <script>javascript:history.go(-1)</script>