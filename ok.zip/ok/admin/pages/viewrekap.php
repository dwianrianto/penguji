
<body background="2.png">
	<style>
		table {
			border-collapse: collapse;
			potition:fixed;
			width:100%;
	}
	/* Zebra striping */
	tr:nth-of-type(odd) { 
		background:#FFF;
	}
	th { 
		background: black; 
		color: white; 
		font-weight: bold; 
		font-size:10pt;
	}
	#ok { 
		padding: 6px; 
		border: 1px solid #ccc; 
		text-align: left; 
		font-size:8pt;
		height:40px;
		text-align:center;
	}
	#ok2 { 
		padding: 6px; 
		border: 1px solid #ccc; 
		text-align: center; 
		font-size:8pt;
		height:10px;
		background-color:#0066CC;
		color:#FFFFFF;
	}
		th {
			text-align:center;
		}
	</style>

<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    	<a href="javascript:;" ><img src="../excel-icon.jpeg" width="18" height="18" border="0" onClick="window.open('./excel/export_excel.php','scrollwindow','top=200,left=300,width=800,height=500');"></a>
                		<br/>
                        	<center>
                            	<b>
                	Rekap Laporan dari Tanggal <?php echo $tgl1=$_POST['tgl1']; ?> Sampai Tanggal <?php echo $tgl2=$_POST['tgl2']; ?>
                    			</b>
                    		</center>
                        <br/>
<div class="container">
    <div class="content">
        <table border="1">
        	<tr>
			<th width="24" rowspan="3">No.</th>
		  <th colspan="4"><center>Permohonan Karoseri</center></th>
			<th width="70" rowspan="3">Nomor SPT</th>
		  <th width="60" rowspan="3">Tanggal SPT</th>
		  <th colspan="4">Cek Fisik Kendaraan</th>
			<th width="70" rowspan="3">Tgl<br/> BAP <br/>Naik</th>
		  <th colspan="2">Terbit BAP</th>
			<th width="102" rowspan="3">Nomor Seri</th>
		  <th width="82" rowspan="3">Keterangan</th>
	  </tr>
      <tr id="ok2">
			<td width="15%" rowspan="2">Permohonan</td>
		  <td width="10%" rowspan="2">Nomor</td>
		  <td width="8%" rowspan="2">Tanggal Surat Masuk</td>
		  <td width="30" rowspan="2">Jml</td>
		  <td width="70" rowspan="2">Tanggal</td>
			<td width="45" rowspan="2">Petugas</td>
			<td colspan="2">Kendaraan</td>
		  <td width="51" rowspan="2">Tanggal</td>
		  <td width="52" rowspan="2">Jumlah</td>
	  </tr>
		<tr id="ok2">
			<td width="32" bgcolor="#009900">Lulus</td>
		  <td width="45" bgcolor="#CE0000">Tidak  Lulus</td>
	  </tr>
		
		
				<?php
																  $no=1;
																  include"../../config/koneksi.php";
																  $tgl1=$_POST['tgl1'];
  $tgl2=$_POST['tgl2'];
																  $query=mysql_query("SELECT
  `pengujian`.`monitoring`.`id_perusahaan`,
  `pengujian`.`monitoring`.*,
  `pengujian`.`perusahaan`.*
FROM
  `pengujian`.`monitoring`
  INNER JOIN `pengujian`.`perusahaan`
    ON `pengujian`.`monitoring`.`id_perusahaan` =
    `pengujian`.`perusahaan`.`id_perusahaan` where monitoring.tgl_p between '$tgl1' and '$tgl2' ");
																  while($data=mysql_fetch_array($query)){  
																?>
		
		<tr id="ok">
			<td><?php echo $no; ?></td>
			<td width="15%"><b><?php echo $data['nama_perusahaan']; ?></b></td>
			<td width="10%"><?php echo $data['nomor_p']; ?></td>
			<td width="6%"><?php echo $data['tgl_p']; ?></td>
			<td width="3%"><font color="#0066FF"><b><?php echo $data['jumlah_k']; ?></b></font></td>
			<td><?php echo $data['no_spt']; ?></td>
			<td width="6%"><?php echo $data['tgl_spt']; ?></td>
			<td width="6%"><?php echo $data['tgl_cek']; ?></td>
			<td width="3%"><?php echo $data['petugas']; ?></td>
			<td width="3%"><font color="#00CC00"><b><?php echo $data['jumlah_lulus']; ?></b></font></td>
			<td width="3%"><font color="#FF0000"><b><?php echo $data['jumlah_tlulus']; ?></b></font></td>
			<td width="6%"><?php echo $data['tgl_bapnaik']; ?></td>
			<td width="6%"><?php echo $data['tgl_terbitbap']; ?></td>
			<td width="3%"><font color="#00CC00"><b><?php echo $data['jumlah_bap']; ?></b></font></td>
			<td width="140px"><?php echo $data['no_seri']; ?></td>
			<td><?php echo $data['keterangan']; ?></td>
		</tr>
		
				<?php $no++;}?>
	</table>
    </div>
</div>
</body>
</html>

