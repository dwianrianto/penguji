<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid;
    padding: 5px;
}

th {text-align: left; background:lightblue;}
</style>
</head>
<body>

<?php
$q = intval($_GET['q']);

include"../config/koneksi.php";
			$query=mysql_query("SELECT * FROM unit WHERE chasis = '".$q."'");

$cek=mysqli_num_rows($query);
			if($cek == 0){
				echo "Belum Pernah di Uji";
			}
	else {

echo "<table>
<tr>
<th>CHASIS</th>
<th>ENGINE</th>
<th>KET</th>
<th>STATUS UNIT</th>
<th>JUMLAH UJI</th>
</tr>";
while($row=mysql_fetch_array($query)){ 
    echo "<tr>";
    echo "<td>" . $row['chasis'] . "</td>";
    echo "<td>" . $row['engine'] . "</td>";
    echo "<td>" . $row['ket'] . "</td>";
		if($row['status_unit'] == 0)
			{
    echo "<td> Belum di Proses Uji </td>";
			}
		if($row['status_unit'] == 1)
			{
    echo "<td><font color=red> Hasil Uji Gagal... </font></td>";
			}
		if($row['status_unit'] == 2)
			{
    echo "<td><font color=green> Hasil Uji Lulus </font></td>";
			}
	echo "<td><a href=?page=pages/historyunit&id=".$row['chasis'].">view</a>" . $row['jumlah_ujiunit'] . "</td>";
    echo "</tr>";
}
echo "</table>";
	}
?>
</body>
</html>