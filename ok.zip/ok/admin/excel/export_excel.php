<?php 
function xlsBOF() {
echo pack("ssssss", 0x809, 0x8, 0x0, 0x10, 0x0, 0x0);
return;
}

function xlsEOF() {
echo pack("ss", 0x0A, 0x00);
return;
}

function xlsWriteNumber($Row, $Col, $Value) {
echo pack("sssss", 0x203, 14, $Row, $Col, 0x0);
echo pack("d", $Value);
return;
}

function xlsWriteLabel($Row, $Col, $Value ) {
$L = strlen($Value);
echo pack("ssssss", 0x204, 8 + $L, $Row, $Col, 0x0, $L);
echo $Value;
return;
}

include "../../config/koneksi.php";

$no=1;
																

$queabsdetail = "SELECT
  `pengujian`.`monitoring`.`id_perusahaan`,
  `pengujian`.`monitoring`.*,
  `pengujian`.`perusahaan`.*
FROM
  `pengujian`.`monitoring`
  LEFT JOIN `pengujian`.`perusahaan`
    ON `pengujian`.`monitoring`.`id_perusahaan` =
    `pengujian`.`perusahaan`.`id_perusahaan`";
$exequeabsdetail = mysql_query($queabsdetail);
while($res = mysql_fetch_array($exequeabsdetail)){

	$data['id_monitoring'][] = $res['id_monitoring'];
	$data['nama_perusahaan'][] = $res['nama_perusahaan'];
	$data['nomor_p'][] = $res['nomor_p'];
	$data['tgl_p'][] = $res['tgl_p'];
	$data['jumlah_k'][] = $res['jumlah_k'];
	$data['no_spt'][] = $res['no_spt'];
	
} 

$jm = sizeof($data['id_monitoring']);
header("Pragma: public" );
header("Expires: 0" );
header("Cache-Control: must-revalidate, post-check=0, pre-check=0" );
header("Content-Type: application/force-download" );
header("Content-Type: application/octet-stream" );
header("Content-Type: application/download" );;
header("Content-Disposition: attachment;filename=file_siswa.xls " );
header("Content-Transfer-Encoding: binary " );
xlsBOF();
xlsWriteLabel(0,3,"Laporan Pegajuan" );
xlsWriteLabel(2,0,"id_monitoring" );
xlsWriteLabel(2,1,"nama_perusahaan" );
xlsWriteLabel(2,2,"Nomor Pengajuan" );
xlsWriteLabel(2,3,"Tgl Pengajuan" );
xlsWriteLabel(2,4,"Jumlah Kendaraan" );
xlsWriteLabel(2,5,"No. SPT" );

$xlsRow = 3;

for ($y=0; $y<$jm; $y++) {
	++$i;
	xlsWriteNumber($xlsRow,0,"$i" );
	xlsWriteLabel($xlsRow,1,$data['nama_perusahaan'][$y]);
	xlsWriteLabel($xlsRow,2,$data['nomor_p'][$y]);
	xlsWriteLabel($xlsRow,3,$data['tgl_p'][$y]);
	xlsWriteLabel($xlsRow,4,$data['jumlah_k'][$y]);
	xlsWriteLabel($xlsRow,5,$data['no_spt'][$y]);
	$xlsRow++;
}
xlsEOF();
exit();