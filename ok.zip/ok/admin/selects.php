<?php
       $servername = "localhost";
       $username = "root";
       $password = "";
       $dbname = "pengujian";
 
       // Create connection
 
       $conn = new mysqli($servername, $username, $password, $dbname);
 
       // Check connection
 
       if ($conn->connect_error) {
 
           die("Connection failed: " . $conn->connect_error);
 
       } 
 
       $sql = "SELECT * from pengajuan
	    where 
		disposisi='0' AND kabid_a = '0' AND kasie_a='0' AND status_spt='0'
	   	OR disposisi='1' AND kabid_a = '0' AND kasie_a='1' AND status_spt='1'
	   ";
       $result = $conn->query($sql);
       $row = $result->fetch_assoc();
       $count = $result->num_rows;
       echo $count;
       $conn->close();
?>