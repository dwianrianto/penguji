<?php
if(isset($_POST['namad']))
{
	?>


<select name="id_type" data-placeholder="Choose a Country..." style="width:350px;" tabindex="2" required="required">
															<option value="">Pilih Type</option>
																<?php
																  include"../../config/koneksi.php";
																  $namad=$_POST['namad'];
																  $query=mysql_query("select * from type where id_merk='$namad'");
																  while($data=mysql_fetch_array($query)){  
																?>
										<option value="<?php echo $data['id_type']; ?>"><?php echo $data['nama_type']; ?></option>
																<?php }  ?>
											</select>
<?php
}
?>