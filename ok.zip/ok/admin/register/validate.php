<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid;
    padding: 5px;
}

th {text-align: left; background:lightblue;}
</style>


<?php
include('../../config/koneksi.php');

if(isset($_POST['namad']))
{
$namad=$_POST['namad'];
$query=mysql_query("select * from unit where chasis='$namad'");
$row=mysql_num_rows($query);
if($row==0)
{
echo "<span style='color:green;'><b>Belum Pernah di Uji</b></span>";
}
else
{
			echo "<table>
<tr>
<th>CHASIS</th>
<th>ENGINE</th>
<th>KET</th>
<th>STATUS UNIT</th>
<th>JUMLAH UJI</th>
</tr>";


while($rows=mysql_fetch_array($query)){


    echo "<tr>";
    echo "<td>" . $rows['chasis'] . "</td>";
    echo "<td>" . $rows['engine'] . "</td>";
    echo "<td>" . $rows['ket'] . "</td>";
		if($rows['status_unit'] == 0)
			{
    echo "<td> Belum di Proses Uji </td>";
			}
		if($rows['status_unit'] == 1)
			{
    echo "<td><font color=red> Hasil Uji Gagal... </font></td>";
			}
		if($rows['status_unit'] == 2)
			{
    echo "<td><font color=green> Hasil Uji Lulus </font></td>";
			}
	echo "<td>" . $rows['jumlah_ujiunit'] . " --> <a href=?page=pages/historyunituji&id=".$rows['chasis'].">View</a></td>";
    echo "</tr>";
}
echo "</table><br/>";
}
}


?>