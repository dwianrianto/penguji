<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid;
    padding: 5px;
}

th {text-align: left; background:lightblue;}
</style>
</head>
<body>

<?php
$q = intval($_GET['q']);

																  include"../config/koneksi.php";
																  $query=mysql_query("select * from perusahaan WHERE id_perusahaan = '".$q."'");
																   
echo "<table>
<tr>
<th>Nama Perusahaan</th>
<th>Jenis Perusahaan</th>
<th>Alamat</th>
<th>Telp</th>
</tr>";
while($row=mysql_fetch_array($query)){ 
    echo "<tr>";
    echo "<td>" . $row['nama_perusahaan'] . "</td>";
    echo "<td>" . $row['jenis_perusahaan'] . "</td>";
    echo "<td>" . $row['alamat_perusahaan'] . "</td>";
    echo "<td>" . $row['telp_perusahaan'] . "</td>";
    echo "</tr>";
}
echo "</table>";
?>
</body>
</html>