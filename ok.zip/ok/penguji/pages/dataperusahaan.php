
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->
	

<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<body>

			<h4>
            	Data Perusahaan
            </h4>
            	<hr/>

	<?php if($_SESSION['level'] == 'admin'){ ?>
								<a href="?page=pages/inputperusahaan">
							<button class="btn btn-sm btn-info"><i class="ace-icon glyphicon glyphicon-plus"></i>Tambah</button>
								</a>
								<a href="?page=pages/inputperusahaan">
							<button class="btn btn-sm btn-warning"><i class="ace-icon fa fa-pencil-square-o"></i>Edit</button>
								</a>
								<br/><br/>
   <?php } ?>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th><b>Nama Perusahaan</b></th>
															<th><b>Jenis</b></th>
															<th><b>Alamat</b></th>
                                                            <th><b>Penanggung Jawab</b></th>
															<th>Telp</th>
                                                            <th>Telp2</th>
                                                            <th>Telp3</th>
                                                            <th>Fax</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("select * from perusahaan where status_perusahaan='0'");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_perusahaan'] ?></td>
															<td><?php echo $data['jenis_perusahaan'] ?></td>
															<td><?php echo $data['alamat_perusahaan'] ?></td>
                                                            <td><?php echo $data['penanggung_jawab'] ?></td>
															<td><?php echo $data['telp_perusahaan'] ?></td>
                                                            <td><?php echo $data['telp_perusahaan2'] ?></td>
                                                            <td><?php echo $data['telp_perusahaan3'] ?></td>
                                                            <td><?php echo $data['fax_perusahaan'] ?></td>
                <td><?php if($_SESSION['level'] == 'admin'){ ?>
                Edit || Delete
                <?php } ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
	</body>