<?php

if(isset($_POST['simpan']) ? $_POST['simpan']: ''){
include "../config/koneksi.php";

$id_pengajuan=$_POST['id_pengajuan'];
$id_detailpengajuan=$_POST['id_detailpengajuan'];
$fisik=$_POST['fisik'];
$panjang=$_POST['panjang'];
$lebar=$_POST['lebar'];
$tinggi=$_POST['tinggi'];
$foh=$_POST['foh'];
$a=$_POST['a'];
$roh=$_POST['roh'];
$i=$_POST['i'];
$ket=$_POST['ket'];
$hasil_cek=$_POST['hasil_cek'];
$foto=$_FILES['new_image']['name'];

		if($fotos=$_FILES['new_image']['name'] != "")
		{
			$imagename = $_FILES['new_image']['name'];
          $source = $_FILES['new_image']['tmp_name'];
          $target = "images/imgproduct/ori/".$imagename;
          move_uploaded_file($source, $target);

          $imagepath = $imagename;
          $save = "images/imgproduct/ori/" . $imagepath; //This is the new file you saving
          $file = "images/imgproduct/ori/" . $imagepath; //This is the original file

          list($width, $height) = getimagesize($file) ; 


          $tn = imagecreatetruecolor($width, $height) ; 
          $image = imagecreatefromjpeg($file) ; 
          imagecopyresampled($tn, $image, 0, 0, 0, 0, $width, $height, $width, $height) ; 

          imagejpeg($tn, $save, 70) ; 

          $save = "images/imgproduct/sml_" . $imagepath; //This is the new file you saving
          $file = "images/imgproduct/ori/" . $imagepath; //This is the original file

          list($width, $height) = getimagesize($file) ; 

          $modwidth = 325; 

          $diff = $width / $modwidth;

          $modheight = 370; 
          $tn = imagecreatetruecolor($modwidth, $modheight) ; 
          $image = imagecreatefromjpeg($file) ; 
          imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 

          imagejpeg($tn, $save, 70) ;



$query3=mysql_query("update detail_pengajuan set fisik='$fisik',panjang='$panjang',lebar='$lebar',tinggi='$tinggi',foh='$foh',a='$a',roh='$roh',i='$i',ket='$ket',hasil_cek='$hasil_cek',foto='sml_$foto' where id_detailpengajuan='$id_detailpengajuan'") or die(mysql_error());

$targets = "images/imgproduct/ori/".$imagename;
unlink($targets);
		}
		else{
			$query3=mysql_query("update detail_pengajuan set fisik='$fisik',panjang='$panjang',lebar='$lebar',tinggi='$tinggi',foh='$foh',a='$a',roh='$roh',i='$i',ket='$ket',hasil_cek='$hasil_cek' where id_detailpengajuan='$id_detailpengajuan'") or die(mysql_error());
          $imagename = $_FILES['new_image']['name'];

      }

?>
	<script>document.location='index.php?page=pages/inputhasiluji&id=<?php echo $id_pengajuan;  ?>';</script>
<?php

		}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>

<?php
																  include"../config/koneksi.php";
																  
																  $id=$_GET['id'];
																  $query2=mysql_query("select
																  						detail_pengajuan.*,
																						sk.*,
																						jenis.*,
																						type.*,
																						merk.*
																						
																  						from detail_pengajuan
																						LEFT JOIN sk ON detail_pengajuan.id_sk=sk.id_sk
																						LEFT JOIN jenis ON sk.id_jenis=jenis.id_jenis
																						LEFT JOIN type ON jenis.id_type=type.id_type
																						LEFT JOIN merk ON type.id_merk=merk.id_merk
																  						where detail_pengajuan.id_detailpengajuan='$id'
	 ");
																  $perusahaan=mysql_fetch_array($query2);
																?>

			<a href="?page=pages/inputhasiluji&id=<?php echo $perusahaan['id_pengajuan']; ?>">
							<button class="btn btn-sm btn-danger"> Back </button>
								</a>

    	<h3>
        	Input Hasil Uji
        </h3>
<hr/>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="signupform" autocomplete="off">
		<input type="hidden" name="id_detailpengajuan" value="<?php echo $id=$_GET['id']; ?>" />
						
																
         <input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Merk / Type</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_merk']; ?>
                                                                         <?php echo $perusahaan['nama_type']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Jenis / Konstruksi</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['nama_jenis']; ?>
                                                                        / <?php echo $perusahaan['nama_konstruksi']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Sk / Tgl</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_sk']; ?>
                                                                         / <?php echo $perusahaan['tgl_sk']; ?></font>
																	</div>
																<br/><br/>
																				<input type="hidden" name="id_pengajuan" value="<?php echo $perusahaan['id_pengajuan']; ?>" />
																	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>No. Chasis</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_chasis']; ?></font>
																	</div>
																<br/><br/>
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>No. Engine</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['no_engine']; ?></font>
																	</div>
																<br/><br/>
                                                                	<label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Ket</b>
																	</label>
																	<div class="col-sm-9">
																		<font size="3"><?php echo $perusahaan['ket_detailpengajuan']; ?></font>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Fisik</b>
																	</label>
																	<div class="col-sm-9">
                                                                    	<select name="fisik" class="col-xs-10 col-sm-5" required >
                                                                        	<option><?php echo $perusahaan['fisik']; ?></option>
                                                                        	<option>sesuai</option>
                                                                            <option>tidak_sesuai</option>
                                                                            <option>belum_ada</option>
                                                                        </select>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Panjang</b>
																	</label>
																	<div class="col-sm-9">
                                <input type="text" name="panjang" id="form-field-1" value="<?php echo $perusahaan['panjang']; ?>" placeholder="Perihal" class="col-xs-10 col-sm-5" required />
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Lebar</b>
																	</label>
																	<div class="col-sm-9">
                                <input type="text" name="lebar" id="form-field-1" placeholder="Perihal" value="<?php echo $perusahaan['lebar']; ?>" class="col-xs-10 col-sm-5" required />
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Tinggi</b>
																	</label>
																	<div class="col-sm-9">
                                <input type="text" name="tinggi" id="form-field-1" placeholder="Perihal" value="<?php echo $perusahaan['tinggi']; ?>" class="col-xs-10 col-sm-5" required />
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>FOH</b>
																	</label>
																	<div class="col-sm-9">
                                <input type="text" name="foh" id="form-field-1" placeholder="Perihal" value="<?php echo $perusahaan['foh']; ?>" class="col-xs-10 col-sm-5" required />
																	</div>
																<br/><br/>
                                                                
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>ROH</b>
																	</label>
																	<div class="col-sm-9">
                                <input type="text" name="roh" id="form-field-1" placeholder="Perihal" value="<?php echo $perusahaan['roh']; ?>" class="col-xs-10 col-sm-5" required />
																	</div>
																<br/><br/>
                                                                
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>KET</b>
																	</label>
																	<div class="col-sm-9">
                                                           			<textarea name="ket" id="form-field-1" placeholder="Perihal" value="<?php echo $perusahaan['ket']; ?>" class="col-xs-10 col-sm-5" required ></textarea>
																	</div>
																<br/><br/><br/>
                                                                
                                                                 <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Hasil Uji</b>
																	</label>
																	<div class="col-sm-9">
                                                                    	<select name="hasil_cek" class="col-xs-10 col-sm-5" required >
                                                                        	<option><?php echo $perusahaan['hasil_cek']; ?></option>
                                                                        	<option>lulus</option>
                                                                            <option>tidak_lulus</option>
                                                                        </select>
																	</div>
																<br/><br/>
                                                                
                                                                <label name="perusahaan" class="col-sm-3 control-label no-padding-right" for="form-field-1">
																		<b>Photo</b>
																	</label>
																	<div class="col-sm-9">
                                                                    
<img src="images/imgproduct/<?php echo $perusahaan['foto']; ?>" width="100px" />
                                                                        <style type="text/css">.thumb-image{width:100px;position:relative;padding:5px;}</style>
                                                                    	<script src="../assets/js/jquery.min.js"></script>
<div id="wrapper" style="margin-top: 20px;">
<input type="file" name="new_image" id="fileUpload" class="textfield" />
<div id="image-holder"></div>
</div>
<script>
$(document).ready(function() {
        $("#fileUpload").on('change', function() {
          //Get count of selected files
          var countFiles = $(this)[0].files.length;
          var imgPath = $(this)[0].value;
          var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
          var image_holder = $("#image-holder");
          image_holder.empty();
          if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
            if (typeof(FileReader) != "undefined") {
              //loop for each file selected for uploaded.
              for (var i = 0; i < countFiles; i++) 
              {
                var reader = new FileReader();
                reader.onload = function(e) {
                  $("<img />", {
                    "src": e.target.result,
                    "class": "thumb-image"
                  }).appendTo(image_holder);
                }
                image_holder.show();
                reader.readAsDataURL($(this)[0].files[i]);
              }
            } else {
              alert("This browser does not support FileReader.");
            }
          } else {
            alert("Pls select only images");
          }
        });
      });
</script>
                                                                        
																	</div>
																<br/><br/>
                                                                
                                                               
                                                                

										<div class="col-md-offset-3 col-md-9">
											<input type="submit" name="simpan" Value="Simpan" class="btn btn-info"  onclick="MM_validateForm(email','hp','','RisNum');return document.MM_returnValue"  />

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
</form>
</body>
</html>
