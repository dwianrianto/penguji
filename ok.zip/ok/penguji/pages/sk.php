
<!--
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css" />
-->


<link rel="stylesheet" href="table/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="table/responsive.bootstrap.min.css" />

<script src="table/jquery-1.12.0.min.js"></script>
<script src="table/jquery.dataTables.min.js"></script>
<script src="table/dataTables.bootstrap.min.js"></script>
<script src="table/dataTables.responsive.min.js"></script>
<script src="table/responsive.bootstrap.min.js"></script>

<!--
<script src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>
-->


<script>
	$(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        columnDefs: [
            { width: '20%', targets: 0 }
        ],
        fixedColumns: true
    } );
} );
</script>

<body>
			
							<div class="btn-group">
												<button class="btn btn-sm btn-info"><i class="ace-icon fa fa-cog"></i>SK/TGL</button>

												<button data-toggle="dropdown" class="btn btn-sm btn-info dropdown-toggle">
													<i class="ace-icon fa fa-angle-down icon-only"></i>
												</button>

												<ul class="dropdown-menu dropdown-yellow">
													<li>
														<a href="?page=pages/tambahsktgl"><i class="ace-icon glyphicon glyphicon-plus"></i>Tambah SK/TGL</a>
													</li>

													<li>
														<a href="#"><i class="ace-icon fa fa-pencil-square-o"></i>Edit SK//TGL</a>
													</li>
												</ul>
							</div><!-- /.btn-group -->
											
											
								<br/><br/>

<table id="example" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
				<th width="5%">No.</th>
                <th>Jenis / Type</th>
				<th>SK / TGL</th>
            </tr>
        </thead>
        <tbody>
																<?php
																  $no=1;
																  include"../config/koneksi.php";
																  $query=mysql_query("SELECT
																		  jenis.*,
																		  type.*,
																		  sk.*
																		FROM
																		  jenis
																		  LEFT JOIN type ON .jenis.id_jenis =
																			type.id_jenis
																		  INNER JOIN sk ON type.id_type =
																			sk.id_type");
																  while($data=mysql_fetch_array($query)){  
																?>
            <tr>
				<td><?php echo $no; ?></td>
                <td><?php echo $data['nama_jenis']; ?> / <?php echo $data['nama_type']; ?></td>
				<td><?php echo $data['no_sk']; ?> / <?php echo $data['tgl_sk']; ?></td>
            </tr>
																<?php $no++;}?>
        </tbody>
    </table>
	</body>